import os
import yaml

CONFIG_PATH = os.path.expanduser("~/.linux-doctor/config.yaml")
DEFAULTS_PATH = os.path.join(os.path.dirname(__file__), "defaults.yaml")


def load():
    """Загружает конфиг: сначала defaults, потом пользовательский поверх."""
    with open(DEFAULTS_PATH) as f:
        config = yaml.safe_load(f)

    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH) as f:
                user = yaml.safe_load(f) or {}
            _deep_merge(config, user)
        except Exception as e:
            print(f"[warn] Ошибка загрузки конфига {CONFIG_PATH}: {e}")

    return config


def _deep_merge(base, override):
    for k, v in override.items():
        if k in base and isinstance(base[k], dict) and isinstance(v, dict):
            _deep_merge(base[k], v)
        else:
            base[k] = v


def init_user_config():
    """Создать пользовательский конфиг если не существует."""
    os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
    if not os.path.exists(CONFIG_PATH):
        import shutil
        shutil.copy(DEFAULTS_PATH, CONFIG_PATH)
        return True
    return False
