class Diagnoser:
    THRESHOLDS = {
        "cpu":       {"warning": 70, "critical": 40},
        "memory":    {"warning": 70, "critical": 40},
        "disk":      {"warning": 60, "critical": 30},
        "security":  {"warning": 80, "critical": 50},
        "hardening": {"warning": 80, "critical": 50},
        "rootkit":   {"warning": 90, "critical": 70},
        "cve":       {"warning": 90, "critical": 60},
        "s.m.a.r.t": {"warning": 90, "critical": 60},
        "users":     {"warning": 80, "critical": 50},
        "services":  {"warning": 80, "critical": 50},
        "hardware":  {"warning": 80, "critical": 50},
        "network":   {"warning": 80, "critical": 50},
    }

    SUGGESTIONS = {
        "cpu":       ["Запустите `htop` для анализа процессов",
                      "Проверьте `ps aux --sort=-%cpu | head -10`"],
        "memory":    ["Запустите `free -h` и `vmstat`",
                      "Проверьте `ps aux --sort=-%mem | head -10`"],
        "disk":      ["Запустите `df -h` для просмотра разделов",
                      "Найдите большие файлы: `du -sh /* 2>/dev/null | sort -rh | head -10`"],
        "security":  ["Отключите парольную аутентификацию SSH",
                      "Запретите вход root по SSH",
                      "Активируйте фаервол: `ufw enable`"],
        "hardening": ["Запустите `linux-doctor --harden` для детального отчёта",
                      "Примените исправления: `linux-doctor --harden -y`"],
        "rootkit":   ["Проверьте `/etc/ld.so.preload` и скрытые файлы в /dev",
                      "Установите и запустите rkhunter: `apt install rkhunter && rkhunter --check`"],
        "cve":       ["Обновите систему: `apt update && apt upgrade`",
                      "Проверьте критичные пакеты: `apt list --upgradable`"],
        "s.m.a.r.t": ["Сделайте резервную копию данных немедленно",
                      "Замените диск при наличии критичных атрибутов"],
        "users":     ["Проверьте `/etc/passwd` на UID 0",
                      "Ограничьте NOPASSWD в sudoers"],
        "services":  ["Проверьте упавшие сервисы: `systemctl --failed`",
                      "Смотрите логи: `journalctl -xe`"],
        "hardware":  ["Проверьте охлаждение при высокой температуре",
                      "Установите haveged для entropy: `apt install haveged`"],
        "network":   ["Проверьте открытые порты: `ss -tulpn`",
                      "Закройте ненужные порты в фаерволе"],
    }

    def run(self, context):
        problems    = []
        suggestions = []

        for module, thresholds in self.THRESHOLDS.items():
            score = context.analysis.get(module, {}).get("score", 100)
            issues = context.analysis.get(module, {}).get("issues", [])

            if score < thresholds["critical"]:
                problems.append(f"КРИТИЧНО: {module.upper()} — score {score}")
                suggestions.extend(self.SUGGESTIONS.get(module, []))
            elif score < thresholds["warning"]:
                problems.append(f"ПРЕДУПРЕЖДЕНИЕ: {module.upper()} — score {score}")
                suggestions.extend(self.SUGGESTIONS.get(module, []))

        if not problems:
            suggestions.append("Система работает нормально — плановая проверка не требуется")

        return {
            "problems":    problems,
            "root_causes": [],
            "suggestions": list(dict.fromkeys(suggestions)),
        }
