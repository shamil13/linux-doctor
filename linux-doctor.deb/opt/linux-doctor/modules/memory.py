import psutil
from core.module import Module

class MemoryModule(Module):
    name = "Memory"
    weight = 15

    def collect(self):
        return {"usage": psutil.virtual_memory().percent}

    def analyze(self, data):
        u = data["usage"]
        if u < 70:
            return {"score": 100, "status": "OK", "issues": []}
        elif u < 90:
            return {"score": 70, "status": "WARNING", "issues": []}
        return {"score": 40, "status": "CRITICAL", "issues": ["High RAM"]}

    def report(self, analysis):
        return analysis