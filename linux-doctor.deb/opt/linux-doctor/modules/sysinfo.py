import subprocess
import os
import platform
import socket
from datetime import datetime
from core.module import Module


class SysInfoModule(Module):
    """Информационный модуль — не влияет на score, только справочная информация."""
    name = "SysInfo"
    weight = 0  # не участвует в общем балле
    informational = True

    def collect(self):
        return {
            "hostname":     socket.gethostname(),
            "os":           self._os_info(),
            "kernel":       platform.release(),
            "kernel_full":  self._kernel_full(),
            "arch":         platform.machine(),
            "cpu_model":    self._cpu_model(),
            "cpu_cores":    os.cpu_count(),
            "ram_total":    self._ram_total(),
            "disks":        self._disks(),
            "virtualization": self._virtualization(),
            "boot_time":    self._boot_time(),
            "ip_addresses": self._ip_addresses(),
            "package_count": self._package_count(),
            "shell":        os.environ.get("SHELL", "?"),
            "python_version": platform.python_version(),
        }

    def _os_info(self):
        try:
            info = {}
            with open("/etc/os-release") as f:
                for line in f:
                    if "=" in line:
                        k, v = line.strip().split("=", 1)
                        info[k] = v.strip('"')
            return info.get("PRETTY_NAME", "Unknown")
        except Exception:
            return platform.platform()

    def _kernel_full(self):
        try:
            r = subprocess.run(["uname", "-a"], capture_output=True, text=True, timeout=5)
            return r.stdout.strip()
        except Exception:
            return platform.platform()

    def _cpu_model(self):
        try:
            with open("/proc/cpuinfo") as f:
                for line in f:
                    if line.startswith("model name"):
                        return line.split(":", 1)[1].strip()
        except Exception:
            pass
        return "Unknown"

    def _ram_total(self):
        try:
            with open("/proc/meminfo") as f:
                for line in f:
                    if line.startswith("MemTotal"):
                        kb = int(line.split()[1])
                        return round(kb / 1024 / 1024, 1)  # GB
        except Exception:
            pass
        return None

    def _disks(self):
        disks = []
        try:
            r = subprocess.run(
                ["df", "-h", "--output=source,size,used,avail,pcent,target"],
                capture_output=True, text=True, timeout=5
            )
            lines = r.stdout.splitlines()[1:]
            for line in lines:
                parts = line.split()
                if len(parts) == 6 and parts[0].startswith("/dev"):
                    disks.append({
                        "device": parts[0], "size": parts[1], "used": parts[2],
                        "avail": parts[3], "pcent": parts[4], "mount": parts[5],
                    })
        except Exception:
            pass
        return disks

    def _virtualization(self):
        try:
            r = subprocess.run(["systemd-detect-virt"], capture_output=True, text=True, timeout=5)
            v = r.stdout.strip()
            return v if v else "none"
        except Exception:
            return "unknown"

    def _boot_time(self):
        try:
            r = subprocess.run(["uptime", "-s"], capture_output=True, text=True, timeout=5)
            return r.stdout.strip()
        except Exception:
            return None

    def _ip_addresses(self):
        ips = []
        try:
            r = subprocess.run(["hostname", "-I"], capture_output=True, text=True, timeout=5)
            ips = r.stdout.strip().split()
        except Exception:
            pass
        return ips

    def _package_count(self):
        try:
            r = subprocess.run(["dpkg-query", "-f", ".", "-W"], capture_output=True, text=True, timeout=10)
            return len(r.stdout)
        except Exception:
            pass
        try:
            r = subprocess.run(["rpm", "-qa"], capture_output=True, text=True, timeout=10)
            return len(r.stdout.splitlines())
        except Exception:
            pass
        return None

    def analyze(self, data):
        # Информационный модуль — всегда OK, без влияния на общий балл
        return {"score": 100, "status": "OK", "issues": [], "informational": True}

    def report(self, analysis):
        return analysis
