import psutil
from core.module import Module

class CPUModule(Module):
    name = "CPU"
    weight = 15

    def collect(self):
        # interval=0.2 вместо 1.0 — достаточно точно, в 5 раз быстрее
        return {"usage": psutil.cpu_percent(interval=0.2)}

    def analyze(self, data):
        u = data["usage"]
        if u < 70:
            score, status = 100, "OK"
        elif u < 90:
            score, status = 70, "WARNING"
        else:
            score, status = 40, "CRITICAL"
        issues = []
        if status != "OK":
            issues.append(f"Высокая загрузка CPU: {u}%")
        return {"score": score, "status": status, "issues": issues}

    def report(self, analysis):
        return analysis
