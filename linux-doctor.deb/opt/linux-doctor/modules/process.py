import psutil
from core.module import Module

class ProcessModule(Module):
    name = "Process"
    weight = 15

    def collect(self):
        top_cpu, top_mem, zombies = [], [], []
        try:
            procs = []
            for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent", "status"]):
                try:
                    procs.append(p.info)
                    if p.info["status"] == psutil.STATUS_ZOMBIE:
                        zombies.append(p.info["pid"])
                except Exception:
                    pass

            top_cpu = sorted(procs, key=lambda x: x.get("cpu_percent") or 0, reverse=True)[:5]
            top_mem = sorted(procs, key=lambda x: x.get("memory_percent") or 0, reverse=True)[:5]
        except Exception:
            pass

        return {
            "top_cpu": [{"pid": p["pid"], "name": p["name"], "cpu": round(p.get("cpu_percent") or 0, 1)} for p in top_cpu],
            "top_mem": [{"pid": p["pid"], "name": p["name"], "mem": round(p.get("memory_percent") or 0, 1)} for p in top_mem],
            "zombies": zombies,
            "total": len(psutil.pids()),
        }

    def analyze(self, data):
        issues = []
        score = 100

        if data["zombies"]:
            issues.append(f"Зомби-процессы: {len(data['zombies'])} шт. (PIDs: {data['zombies'][:5]})")
            score -= 20

        if data["top_cpu"] and data["top_cpu"][0]["cpu"] > 80:
            p = data["top_cpu"][0]
            issues.append(f"Процесс {p['name']} (PID {p['pid']}) потребляет {p['cpu']}% CPU")
            score -= 20

        if data["top_mem"] and data["top_mem"][0]["mem"] > 50:
            p = data["top_mem"][0]
            issues.append(f"Процесс {p['name']} (PID {p['pid']}) потребляет {p['mem']}% RAM")
            score -= 20

        status = "OK" if score >= 80 else ("WARNING" if score >= 50 else "CRITICAL")
        return {"score": max(score, 0), "status": status, "issues": issues}

    def report(self, analysis):
        return analysis
