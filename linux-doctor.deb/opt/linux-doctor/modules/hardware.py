import subprocess
import os
from core.module import Module


class HardwareModule(Module):
    name = "Hardware"
    weight = 10

    def collect(self):
        return {
            "temps":   self._temperatures(),
            "entropy": self._entropy(),
            "load":    self._load_avg(),
            "uptime":  self._uptime(),
        }

    def _temperatures(self):
        temps = {}
        # sensors (lm-sensors)
        try:
            r = subprocess.run(["sensors", "-j"], capture_output=True, text=True, timeout=5)
            import json
            data = json.loads(r.stdout)
            for chip, values in data.items():
                for key, val in values.items():
                    if isinstance(val, dict):
                        for subkey, subval in val.items():
                            if "input" in subkey and isinstance(subval, (int, float)):
                                label = f"{chip}/{key}"
                                temps[label] = round(subval, 1)
        except Exception:
            pass

        # Fallback: /sys/class/thermal
        if not temps:
            try:
                base = "/sys/class/thermal"
                for zone in os.listdir(base):
                    if not zone.startswith("thermal_zone"):
                        continue
                    temp_file = os.path.join(base, zone, "temp")
                    type_file = os.path.join(base, zone, "type")
                    try:
                        temp = int(open(temp_file).read()) / 1000
                        ztype = open(type_file).read().strip()
                        temps[ztype] = round(temp, 1)
                    except Exception:
                        pass
            except Exception:
                pass
        return temps

    def _entropy(self):
        try:
            val = int(open("/proc/sys/kernel/random/entropy_avail").read())
            pool = int(open("/proc/sys/kernel/random/poolsize").read())
            return {"available": val, "pool": pool, "percent": round(val / pool * 100)}
        except Exception:
            return None

    def _load_avg(self):
        try:
            with open("/proc/loadavg") as f:
                parts = f.read().split()
                return {
                    "1min":  float(parts[0]),
                    "5min":  float(parts[1]),
                    "15min": float(parts[2]),
                }
        except Exception:
            return None

    def _uptime(self):
        try:
            with open("/proc/uptime") as f:
                seconds = float(f.read().split()[0])
            days = int(seconds // 86400)
            hours = int((seconds % 86400) // 3600)
            return f"{days}d {hours}h"
        except Exception:
            return None

    def analyze(self, data):
        issues = []
        score = 100

        for name, temp in data["temps"].items():
            if temp > 85:
                issues.append(f"Критичная температура {name}: {temp}°C")
                score -= 30
            elif temp > 70:
                issues.append(f"Высокая температура {name}: {temp}°C")
                score -= 15

        entropy = data.get("entropy")
        if entropy:
            if entropy["available"] < 100:
                issues.append(f"Критически низкий entropy: {entropy['available']} бит")
                score -= 20
            elif entropy["available"] < 500:
                issues.append(f"Низкий entropy: {entropy['available']} бит (рекомендуется > 1000)")
                score -= 10

        load = data.get("load")
        if load:
            import os as _os
            try:
                cpus = _os.cpu_count() or 1
            except Exception:
                cpus = 1
            if load["15min"] > cpus * 2:
                issues.append(f"Очень высокий load average: {load['15min']} (CPU: {cpus})")
                score -= 20
            elif load["15min"] > cpus:
                issues.append(f"Высокий load average: {load['15min']} (CPU: {cpus})")
                score -= 10

        status = "OK" if score >= 80 else ("WARNING" if score >= 50 else "CRITICAL")
        return {"score": max(score, 0), "status": status, "issues": issues}

    def report(self, analysis):
        return analysis
