import subprocess
import os
from core.module import Module

class SecurityModule(Module):
    name = "Security"
    weight = 25

    def collect(self):
        data = {
            "ssh_password": self._check_ssh_password(),
            "root_login": self._check_root_login(),
            "firewall": self._check_firewall(),
        }
        return data

    def _check_ssh_password(self):
        try:
            result = subprocess.run(
                ["sshd", "-T"], capture_output=True, text=True, timeout=5
            )
            return "passwordauthentication yes" in result.stdout.lower()
        except Exception:
            # Если sshd недоступен — читаем конфиг напрямую
            try:
                with open("/etc/ssh/sshd_config") as f:
                    for line in f:
                        line = line.strip().lower()
                        if line.startswith("passwordauthentication"):
                            return "yes" in line
            except Exception:
                pass
        return False

    def _check_root_login(self):
        try:
            result = subprocess.run(
                ["sshd", "-T"], capture_output=True, text=True, timeout=5
            )
            return "permitrootlogin yes" in result.stdout.lower()
        except Exception:
            try:
                with open("/etc/ssh/sshd_config") as f:
                    for line in f:
                        line = line.strip().lower()
                        if line.startswith("permitrootlogin"):
                            return "yes" in line
            except Exception:
                pass
        return False

    def _check_firewall(self):
        for cmd in [["ufw", "status"], ["firewall-cmd", "--state"]]:
            try:
                r = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
                out = r.stdout.lower()
                if "active" in out or "running" in out:
                    return True
            except Exception:
                pass
        # Проверяем iptables как запасной вариант
        try:
            r = subprocess.run(
                ["iptables", "-L", "-n"], capture_output=True, text=True, timeout=5
            )
            lines = [l for l in r.stdout.splitlines() if l.strip() and not l.startswith("Chain") and not l.startswith("target")]
            return len(lines) > 0
        except Exception:
            pass
        return False

    def analyze(self, data):
        issues = []
        score = 100

        if data["ssh_password"]:
            issues.append("SSH: разрешена аутентификация по паролю")
            score -= 30

        if data["root_login"]:
            issues.append("SSH: разрешён вход под root")
            score -= 30

        if not data["firewall"]:
            issues.append("Фаервол не активен (ufw/firewalld/iptables)")
            score -= 20

        status = "OK" if score >= 80 else ("WARNING" if score >= 50 else "CRITICAL")
        return {"score": max(score, 0), "status": status, "issues": issues}

    def report(self, analysis):
        return analysis
