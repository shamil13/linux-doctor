import subprocess
import os
import time
from core.module import Module

# Кэш в памяти на время сессии (не бить apt каждый раз при --watch)
_CACHE = {"ts": 0, "result": None}
CACHE_TTL = 300  # 5 минут


class UpdateModule(Module):
    name = "Updates"
    weight = 10

    def collect(self):
        return {
            "security_updates": self._security_updates(),
            "last_update_days": self._last_update_days(),
            "package_manager":  self._detect_pm(),
        }

    def _detect_pm(self):
        for pm in ["apt", "dnf", "yum", "pacman", "zypper"]:
            try:
                subprocess.run([pm, "--version"], capture_output=True, timeout=2)
                return pm
            except Exception:
                pass
        return None

    def _security_updates(self):
        global _CACHE
        if time.time() - _CACHE["ts"] < CACHE_TTL and _CACHE["result"] is not None:
            return _CACHE["result"]

        count = 0

        # 1. apt-check — быстрее всего (~0.1с), есть на Debian/Ubuntu/Kali
        try:
            r = subprocess.run(
                ["/usr/lib/update-notifier/apt-check"],
                capture_output=True, text=True, timeout=4
            )
            output = (r.stderr or r.stdout).strip()
            if ";" in output:
                count = int(output.split(";")[1])
                _CACHE = {"ts": time.time(), "result": count}
                return count
        except Exception:
            pass

        # 2. apt list --upgradable с жёстким таймаутом
        try:
            r = subprocess.run(
                ["apt", "list", "--upgradable"],
                capture_output=True, text=True, timeout=4,
                env={**os.environ, "DEBIAN_FRONTEND": "noninteractive"}
            )
            count = sum(1 for l in r.stdout.splitlines()
                        if "security" in l.lower())
        except Exception:
            pass

        # 3. dnf/yum
        if count == 0:
            try:
                r = subprocess.run(
                    ["dnf", "updateinfo", "list", "security"],
                    capture_output=True, text=True, timeout=6
                )
                count = len([l for l in r.stdout.splitlines() if l.strip()])
            except Exception:
                pass

        _CACHE = {"ts": time.time(), "result": count}
        return count

    def _last_update_days(self):
        for path in ["/var/log/dpkg.log", "/var/log/dnf.log",
                     "/var/log/yum.log", "/var/cache/pacman/pkg"]:
            if os.path.exists(path):
                return int((time.time() - os.path.getmtime(path)) / 86400)
        return None

    def analyze(self, data):
        issues = []
        score = 100

        sec = data["security_updates"]
        if sec > 0:
            issues.append(f"Доступно обновлений безопасности: {sec}")
            score -= min(sec * 5, 40)

        days = data["last_update_days"]
        if days is not None:
            if days > 90:
                issues.append(f"Система не обновлялась {days} дней")
                score -= 30
            elif days > 30:
                issues.append(f"Последнее обновление {days} дней назад")
                score -= 15

        status = "OK" if score >= 80 else ("WARNING" if score >= 50 else "CRITICAL")
        return {"score": max(score, 0), "status": status, "issues": issues}

    def report(self, analysis):
        return analysis
