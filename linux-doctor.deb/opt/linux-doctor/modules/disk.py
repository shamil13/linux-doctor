import psutil
from core.module import Module

class DiskModule(Module):
    name = "Disk"
    weight = 20

    def collect(self):
        return {"usage": psutil.disk_usage("/").percent}

    def analyze(self, data):
        u = data["usage"]
        if u < 70:
            return {"score": 100, "status": "OK", "issues": []}
        elif u < 90:
            return {"score": 60, "status": "WARNING", "issues": ["Disk usage high"]}
        return {"score": 30, "status": "CRITICAL", "issues": ["Disk full"]}

    def report(self, analysis):
        return analysis