import subprocess
import os
import stat
from core.module import Module


class HardeningModule(Module):
    name = "Hardening"
    weight = 20

    # Желаемые значения sysctl
    SYSCTL_CHECKS = {
        "net.ipv4.ip_forward":                  ("0",  "IP forwarding должен быть отключён"),
        "net.ipv4.conf.all.send_redirects":      ("0",  "Отправка ICMP-редиректов должна быть отключена"),
        "net.ipv4.conf.all.accept_redirects":    ("0",  "Приём ICMP-редиректов должен быть отключён"),
        "net.ipv4.conf.all.accept_source_route": ("0",  "Source routing должен быть отключён"),
        "net.ipv4.tcp_syncookies":               ("1",  "SYN-flood защита должна быть включена"),
        "net.ipv4.conf.all.log_martians":        ("1",  "Логирование martian-пакетов должно быть включено"),
        "net.ipv4.icmp_echo_ignore_broadcasts":  ("1",  "Игнорирование broadcast ICMP должно быть включено"),
        "kernel.randomize_va_space":             ("2",  "ASLR должен быть включён (значение 2)"),
        "kernel.dmesg_restrict":                 ("1",  "dmesg должен быть ограничен для обычных пользователей"),
        "kernel.core_uses_pid":                  ("1",  "Core dumps должны включать PID"),
        "fs.suid_dumpable":                      ("0",  "SUID core dumps должны быть отключены"),
        "net.ipv6.conf.all.disable_ipv6":        (None, None),  # только читаем, не требуем
    }

    def collect(self):
        return {
            "sysctl":      self._check_sysctl(),
            "ssh":         self._check_ssh_hardening(),
            "pam":         self._check_pam(),
            "suid_files":  self._find_suid(),
            "apparmor":    self._check_apparmor(),
            "auditd":      self._check_auditd(),
            "umask":       self._check_umask(),
            "cron_perms":  self._check_cron_perms(),
            "core_dumps":  self._check_core_dumps(),
        }

    # ── sysctl ──────────────────────────────────────────────────────────────
    def _check_sysctl(self):
        results = {}
        for key, (expected, _) in self.SYSCTL_CHECKS.items():
            if expected is None:
                continue
            try:
                r = subprocess.run(
                    ["sysctl", "-n", key],
                    capture_output=True, text=True, timeout=5
                )
                val = r.stdout.strip()
                results[key] = {"value": val, "ok": val == expected, "expected": expected}
            except Exception:
                results[key] = {"value": None, "ok": None, "expected": expected}
        return results

    # ── SSH hardening ────────────────────────────────────────────────────────
    def _check_ssh_hardening(self):
        checks = {
            "Protocol":                   ("2",   "Protocol 2"),
            "PermitRootLogin":            ("no",  "PermitRootLogin no"),
            "PasswordAuthentication":     ("no",  "PasswordAuthentication no"),
            "PermitEmptyPasswords":       ("no",  "PermitEmptyPasswords no"),
            "X11Forwarding":              ("no",  "X11Forwarding no"),
            "MaxAuthTries":               ("4",   "MaxAuthTries <= 4"),
            "LoginGraceTime":             ("60",  "LoginGraceTime <= 60"),
            "AllowAgentForwarding":       ("no",  "AllowAgentForwarding no"),
            "ClientAliveInterval":        ("300", "ClientAliveInterval установлен"),
            "ClientAliveCountMax":        ("2",   "ClientAliveCountMax <= 2"),
        }
        results = {}
        try:
            r = subprocess.run(
                ["sshd", "-T"], capture_output=True, text=True, timeout=5
            )
            conf = {line.split()[0].lower(): line.split()[1]
                    for line in r.stdout.splitlines() if len(line.split()) >= 2}
            for param, (expected, desc) in checks.items():
                val = conf.get(param.lower())
                if val is None:
                    results[param] = {"ok": False, "value": None, "desc": desc}
                elif param in ("MaxAuthTries", "LoginGraceTime", "ClientAliveCountMax"):
                    try:
                        results[param] = {"ok": int(val) <= int(expected), "value": val, "desc": desc}
                    except Exception:
                        results[param] = {"ok": False, "value": val, "desc": desc}
                else:
                    results[param] = {"ok": val.lower() == expected.lower(), "value": val, "desc": desc}
        except Exception:
            pass
        return results

    # ── PAM ─────────────────────────────────────────────────────────────────
    def _check_pam(self):
        pam = {"password_complexity": False, "account_lockout": False}
        for path in ["/etc/pam.d/common-password", "/etc/pam.d/system-auth"]:
            if os.path.exists(path):
                try:
                    content = open(path).read().lower()
                    if "pam_pwquality" in content or "pam_cracklib" in content:
                        pam["password_complexity"] = True
                    if "pam_tally2" in content or "pam_faillock" in content:
                        pam["account_lockout"] = True
                except Exception:
                    pass
        return pam

    # ── SUID/SGID ────────────────────────────────────────────────────────────
    def _find_suid(self):
        KNOWN_SUID = {
            "/usr/bin/sudo", "/usr/bin/passwd", "/usr/bin/su",
            "/usr/bin/newgrp", "/usr/bin/gpasswd", "/usr/bin/chsh",
            "/usr/bin/chfn", "/bin/mount", "/bin/umount", "/bin/ping",
            "/sbin/unix_chkpwd", "/usr/lib/openssh/ssh-keysign",
        }
        suspicious = []
        try:
            r = subprocess.run(
                ["find", "/usr", "/bin", "/sbin", "-perm", "/4000", "-o", "-perm", "/2000"],
                capture_output=True, text=True, timeout=15
            )
            for f in r.stdout.splitlines():
                f = f.strip()
                if f and f not in KNOWN_SUID:
                    suspicious.append(f)
        except Exception:
            pass
        return suspicious

    # ── AppArmor / SELinux ───────────────────────────────────────────────────
    def _check_apparmor(self):
        result = {"apparmor": False, "selinux": False, "profiles_enforced": 0}
        try:
            r = subprocess.run(["aa-status", "--json"], capture_output=True, text=True, timeout=5)
            if r.returncode == 0:
                import json
                data = json.loads(r.stdout)
                result["apparmor"] = True
                result["profiles_enforced"] = data.get("profiles", {}).get("enforce", 0)
        except Exception:
            pass
        try:
            r = subprocess.run(["getenforce"], capture_output=True, text=True, timeout=5)
            if "enforcing" in r.stdout.lower():
                result["selinux"] = True
        except Exception:
            pass
        return result

    # ── auditd ───────────────────────────────────────────────────────────────
    def _check_auditd(self):
        try:
            r = subprocess.run(
                ["systemctl", "is-active", "auditd"],
                capture_output=True, text=True, timeout=5
            )
            return r.stdout.strip() == "active"
        except Exception:
            return False

    # ── umask ────────────────────────────────────────────────────────────────
    def _check_umask(self):
        secure = False
        for path in ["/etc/profile", "/etc/login.defs", "/etc/bash.bashrc"]:
            try:
                content = open(path).read()
                if "umask 027" in content or "umask 077" in content:
                    secure = True
                    break
            except Exception:
                pass
        return secure

    # ── cron permissions ─────────────────────────────────────────────────────
    def _check_cron_perms(self):
        issues = []
        for path in ["/etc/crontab", "/etc/cron.d", "/var/spool/cron"]:
            if os.path.exists(path):
                try:
                    s = os.stat(path)
                    mode = oct(s.st_mode)[-3:]
                    if mode not in ("600", "700", "640", "750"):
                        issues.append(f"{path}: права {mode} (должно быть 600/700)")
                except Exception:
                    pass
        return issues

    # ── core dumps ───────────────────────────────────────────────────────────
    def _check_core_dumps(self):
        disabled = False
        for path in ["/etc/security/limits.conf", "/etc/security/limits.d/10-hardening.conf"]:
            try:
                content = open(path).read()
                if "core" in content and "0" in content:
                    disabled = True
                    break
            except Exception:
                pass
        return disabled

    # ── analyze ──────────────────────────────────────────────────────────────
    def analyze(self, data):
        issues = []
        score = 100

        # sysctl
        failed_sysctl = [k for k, v in data["sysctl"].items() if not v["ok"]]
        if failed_sysctl:
            score -= min(len(failed_sysctl) * 4, 30)
            for k in failed_sysctl[:3]:
                desc = self.SYSCTL_CHECKS[k][1]
                issues.append(f"sysctl: {desc}")
            if len(failed_sysctl) > 3:
                issues.append(f"...ещё {len(failed_sysctl)-3} sysctl-параметров не настроены")

        # SSH
        failed_ssh = [v["desc"] for v in data["ssh"].values() if not v["ok"]]
        if failed_ssh:
            score -= min(len(failed_ssh) * 5, 25)
            for d in failed_ssh[:3]:
                issues.append(f"SSH: {d}")
            if len(failed_ssh) > 3:
                issues.append(f"...ещё {len(failed_ssh)-3} SSH-параметров не настроены")

        # PAM
        if not data["pam"]["password_complexity"]:
            issues.append("PAM: не настроена политика сложности паролей")
            score -= 10
        if not data["pam"]["account_lockout"]:
            issues.append("PAM: не настроена блокировка после неудачных входов")
            score -= 10

        # SUID
        if data["suid_files"]:
            issues.append(f"SUID/SGID: {len(data['suid_files'])} подозрительных файлов")
            score -= min(len(data["suid_files"]) * 5, 15)

        # AppArmor/SELinux
        if not data["apparmor"]["apparmor"] and not data["apparmor"]["selinux"]:
            issues.append("MAC: AppArmor и SELinux не активны")
            score -= 10

        # auditd
        if not data["auditd"]:
            issues.append("auditd: сервис аудита не запущен")
            score -= 5

        # umask
        if not data["umask"]:
            issues.append("umask: не настроен безопасный umask (027/077)")
            score -= 5

        # cron
        if data["cron_perms"]:
            for c in data["cron_perms"]:
                issues.append(f"Cron: {c}")
            score -= 5

        # core dumps
        if not data["core_dumps"]:
            issues.append("Core dumps: не отключены в limits.conf")
            score -= 5

        status = "OK" if score >= 80 else ("WARNING" if score >= 50 else "CRITICAL")
        return {"score": max(score, 0), "status": status, "issues": issues}

    def report(self, analysis):
        return analysis
