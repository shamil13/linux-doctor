import subprocess
import os
import stat
import hashlib
from core.module import Module


class RootkitModule(Module):
    name = "Rootkit"
    weight = 20
    RUN_RKHUNTER = False  # включается только через --run-rkhunter

    # Известные файлы rootkit'ов
    KNOWN_ROOTKIT_FILES = [
        "/usr/bin/bdsh", "/usr/bin/lsh", "/usr/bin/sshd2",
        "/etc/cron.d/.placeholder2", "/tmp/.ICE-unix/.X11",
        "/dev/ttyof", "/dev/ptyxx", "/dev/.bash_history",
        "/.bash_history", "/usr/lib/libproc.a",
    ]

    # Подозрительные скрытые файлы в системных директориях
    SUSPICIOUS_DIRS = ["/tmp", "/dev", "/var/tmp", "/usr/lib"]

    # Системные бинари которые не должны быть модифицированы
    CRITICAL_BINS = [
        "/bin/ls", "/bin/ps", "/bin/netstat", "/usr/bin/who",
        "/usr/bin/w", "/usr/sbin/ss", "/bin/find",
    ]

    def collect(self):
        return {
            "known_files":      self._check_known_files(),
            "hidden_in_dev":    self._check_hidden_dev(),
            "preload":          self._check_preload(),
            "suspicious_procs": self._check_proc_hiding(),
            "passwd_anomalies": self._check_passwd(),
            "sudoers_nopasswd": self._check_sudoers(),
            "rkhunter":         self._run_rkhunter(),
        }

    def _check_known_files(self):
        found = []
        for path in self.KNOWN_ROOTKIT_FILES:
            if os.path.exists(path):
                found.append(path)
        return found

    def _check_hidden_dev(self):
        """Скрытые файлы в /dev — нетипично и подозрительно."""
        suspicious = []
        try:
            for entry in os.scandir("/dev"):
                if entry.name.startswith(".") and entry.name not in (".", ".."):
                    suspicious.append(entry.path)
        except Exception:
            pass
        return suspicious

    def _check_preload(self):
        """LD_PRELOAD и /etc/ld.so.preload — классический способ скрыть rootkit."""
        result = {"ld_so_preload": False, "contents": []}
        path = "/etc/ld.so.preload"
        if os.path.exists(path):
            result["ld_so_preload"] = True
            try:
                with open(path) as f:
                    result["contents"] = [l.strip() for l in f if l.strip()]
            except Exception:
                pass
        return result

    def _check_proc_hiding(self):
        """Сравниваем PID из /proc с выводом ps — расхождение = rootkit.
        Ядерные потоки (kthread, kworker и др.) видны в /proc но не в ps — это норма."""
        proc_pids = set()
        ps_pids   = set()
        try:
            for entry in os.scandir("/proc"):
                if entry.name.isdigit():
                    proc_pids.add(int(entry.name))
        except Exception:
            pass
        try:
            r = subprocess.run(
                ["ps", "-e", "-o", "pid="],
                capture_output=True, text=True, timeout=5
            )
            for line in r.stdout.splitlines():
                line = line.strip()
                if line.isdigit():
                    ps_pids.add(int(line))
        except Exception:
            pass

        if not proc_pids or not ps_pids:
            return []

        diff = proc_pids - ps_pids - {1, 2}
        hidden = []
        for pid in diff:
            if pid <= 10:
                continue
            # Пропускаем ядерные потоки — они в /proc но не в ps -e
            try:
                comm = open(f"/proc/{pid}/comm").read().strip()
                # Ядерные потоки: kworker, kthread, migration, rcu_*, ksoftirqd и др.
                if any(comm.startswith(k) for k in (
                    "kworker", "kthread", "migration", "rcu_", "ksoftirqd",
                    "watchdog", "cpuhp", "irq/", "idle_inject", "card", "v4l2",
                    "cfg80211", "scsi_", "dm-", "jbd2", "ext4-", "xfsaild",
                    "loop", "nvme", "mpt", "kcompact", "khugepaged", "kswapd",
                )):
                    continue
                # Проверяем что процесс реально существует и не kernel thread
                status_file = f"/proc/{pid}/status"
                if os.path.exists(status_file):
                    content = open(status_file).read()
                    # VmSize отсутствует у ядерных потоков
                    if "VmSize:" not in content:
                        continue
                hidden.append(pid)
            except (FileNotFoundError, ProcessLookupError):
                pass  # процесс завершился пока мы проверяли
            except Exception:
                hidden.append(pid)

        return hidden[:10]

    def _check_passwd(self):
        """UID 0 у не-root пользователей, пустые пароли."""
        anomalies = []
        try:
            with open("/etc/passwd") as f:
                for line in f:
                    parts = line.strip().split(":")
                    if len(parts) < 4:
                        continue
                    user, _, uid, _ = parts[0], parts[1], parts[2], parts[3]
                    if uid == "0" and user != "root":
                        anomalies.append(f"UID 0 у пользователя {user!r}")
        except Exception:
            pass
        try:
            with open("/etc/shadow") as f:
                for line in f:
                    parts = line.strip().split(":")
                    if len(parts) >= 2:
                        user, pw = parts[0], parts[1]
                        if pw == "" and user not in ("root",):
                            anomalies.append(f"Пустой пароль у {user!r}")
        except PermissionError:
            pass
        except Exception:
            pass
        return anomalies

    def _check_sudoers(self):
        """NOPASSWD в sudoers — опасно если не намеренно."""
        found = []
        paths = ["/etc/sudoers"] + [
            f"/etc/sudoers.d/{f}" for f in
            (os.listdir("/etc/sudoers.d") if os.path.exists("/etc/sudoers.d") else [])
        ]
        for path in paths:
            try:
                with open(path) as f:
                    for i, line in enumerate(f, 1):
                        if "NOPASSWD" in line and not line.strip().startswith("#"):
                            found.append(f"{path}:{i}: {line.strip()}")
            except Exception:
                pass
        return found

    def _run_rkhunter(self):
        """rkhunter запускается только с флагом --run-rkhunter (иначе слишком долго)."""
        import shutil
        available = shutil.which("rkhunter") is not None
        if not self.RUN_RKHUNTER:
            return {"available": available, "warnings": [], "skipped": True}
        try:
            r = subprocess.run(
                ["rkhunter", "--check", "--skip-keypress", "--quiet", "--nocolors"],
                capture_output=True, text=True, timeout=120
            )
            warnings = [l for l in r.stdout.splitlines() if "Warning" in l or "INFECTED" in l]
            return {"available": True, "warnings": warnings[:10], "skipped": False}
        except Exception as e:
            return {"available": available, "warnings": [str(e)], "skipped": False}

    def analyze(self, data):
        issues = []
        score = 100

        if data["known_files"]:
            score -= 40
            for f in data["known_files"]:
                issues.append(f"Найден известный rootkit-файл: {f}")

        if data["hidden_in_dev"]:
            score -= 20
            issues.append(f"Скрытые файлы в /dev: {', '.join(data['hidden_in_dev'][:3])}")

        if data["preload"]["ld_so_preload"]:
            score -= 25
            contents = data["preload"]["contents"]
            issues.append(f"/etc/ld.so.preload существует: {contents}")

        if data["suspicious_procs"]:
            score -= 30
            issues.append(f"Скрытые процессы (в /proc но не в ps): {data['suspicious_procs'][:5]}")

        for a in data["passwd_anomalies"]:
            score -= 20
            issues.append(a)

        if data["sudoers_nopasswd"]:
            score -= 10
            for s in data["sudoers_nopasswd"][:3]:
                issues.append(f"sudo NOPASSWD: {s}")

        rk = data["rkhunter"]
        if rk["available"] and not rk.get("skipped") and rk["warnings"]:
            score -= min(len(rk["warnings"]) * 5, 20)
            for w in rk["warnings"][:3]:
                issues.append(f"rkhunter: {w.strip()}")

        status = "OK" if score >= 80 else ("WARNING" if score >= 50 else "CRITICAL")
        return {"score": max(score, 0), "status": status, "issues": issues}

    def report(self, analysis):
        return analysis
