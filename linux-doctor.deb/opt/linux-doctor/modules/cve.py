import subprocess
import requests
from core.module import Module
from storage import cve_cache


class CVEModule(Module):
    name = "CVE"
    weight = 20

    HIGH_RISK = {
        "openssl", "openssh-server", "openssh-client", "libssl",
        "curl", "libcurl", "python3", "sudo", "bash", "nginx",
        "apache2", "libc6", "libgnutls", "bind9", "postfix",
    }

    # Глобальные флаги выставляются перед collect() через set_mode()
    OFFLINE = False
    FORCE_REFRESH = False

    @classmethod
    def set_mode(cls, offline=False, force_refresh=False):
        cls.OFFLINE = offline
        cls.FORCE_REFRESH = force_refresh

    def collect(self):
        packages = self._get_packages()
        kernel   = self._get_kernel()
        risky    = [p for p in packages if p["name"] in self.HIGH_RISK]
        key      = cve_cache.make_key(kernel, risky)

        cves        = None
        cache_used  = False
        cache_age   = None

        if not self.FORCE_REFRESH:
            cves = cve_cache.get_valid(key, ignore_ttl=self.OFFLINE)
            if cves is not None:
                cache_used = True
                cache_age  = cve_cache.age_seconds()

        if cves is None:
            if self.OFFLINE:
                # Нет валидного кэша и нет сети — возвращаем пусто
                cves = []
            else:
                cves = self._check_cves(packages, kernel)
                cve_cache.save(key, cves)

        return {
            "kernel":   kernel,
            "packages": packages[:20],
            "cves":     cves,
            "total_checked": len(packages),
            "cache_used": cache_used,
            "cache_age":  cache_age,
            "offline":   self.OFFLINE,
        }

    def _get_kernel(self):
        try:
            r = subprocess.run(["uname", "-r"], capture_output=True, text=True)
            return r.stdout.strip()
        except Exception:
            return None

    def _get_packages(self):
        packages = []
        # dpkg (Debian/Ubuntu/Kali)
        try:
            r = subprocess.run(
                ["dpkg-query", "-W", "-f=${Package} ${Version}\n"],
                capture_output=True, text=True, timeout=15
            )
            for line in r.stdout.splitlines():
                parts = line.strip().split(" ", 1)
                if len(parts) == 2:
                    packages.append({"name": parts[0], "version": parts[1]})
            return packages
        except Exception:
            pass
        # rpm (RHEL/CentOS)
        try:
            r = subprocess.run(
                ["rpm", "-qa", "--queryformat", "%{NAME} %{VERSION}\n"],
                capture_output=True, text=True, timeout=15
            )
            for line in r.stdout.splitlines():
                parts = line.strip().split(" ", 1)
                if len(parts) == 2:
                    packages.append({"name": parts[0], "version": parts[1]})
        except Exception:
            pass
        return packages

    def _check_cves(self, packages, kernel):
        """Проверяем через debian security tracker API и OSV."""
        cves = []

        # Проверка ядра через CVE API
        if kernel:
            cves += self._check_kernel_cves(kernel)

        # Проверка пакетов через OSV.dev
        risky = [p for p in packages if p["name"] in self.HIGH_RISK]
        for pkg in risky[:10]:
            found = self._osv_check(pkg["name"], pkg["version"])
            cves.extend(found)

        return cves

    def _check_kernel_cves(self, kernel):
        """Ищем CVE для версии ядра через NIST NVD API (публичный)."""
        cves = []
        try:
            version = kernel.split("-")[0]
            url = (
                f"https://services.nvd.nist.gov/rest/json/cves/2.0"
                f"?keywordSearch=linux+kernel+{version}&resultsPerPage=5"
            )
            r = requests.get(url, timeout=10)
            if r.status_code == 200:
                data = r.json()
                for item in data.get("vulnerabilities", [])[:3]:
                    cve = item.get("cve", {})
                    cid = cve.get("id", "")
                    desc = cve.get("descriptions", [{}])[0].get("value", "")[:120]
                    metrics = cve.get("metrics", {})
                    score = None
                    for key in ("cvssMetricV31", "cvssMetricV30", "cvssMetricV2"):
                        if key in metrics:
                            score = metrics[key][0].get("cvssData", {}).get("baseScore")
                            break
                    if cid and score and float(score) >= 7.0:
                        cves.append({
                            "id": cid,
                            "component": f"kernel {version}",
                            "score": score,
                            "desc": desc,
                        })
        except Exception:
            pass
        return cves

    def _osv_check(self, package, version):
        """Проверка через OSV.dev API."""
        cves = []
        try:
            payload = {
                "package": {"name": package, "ecosystem": "Debian"},
                "version": version,
            }
            r = requests.post(
                "https://api.osv.dev/v1/query",
                json=payload, timeout=8
            )
            if r.status_code == 200:
                for vuln in r.json().get("vulns", [])[:3]:
                    vid = vuln.get("id", "")
                    aliases = vuln.get("aliases", [])
                    cve_id = next((a for a in aliases if a.startswith("CVE-")), vid)
                    summary = vuln.get("summary", "")[:100]
                    severity = vuln.get("database_specific", {}).get("severity", "UNKNOWN")
                    if severity in ("HIGH", "CRITICAL"):
                        cves.append({
                            "id": cve_id,
                            "component": f"{package} {version}",
                            "score": severity,
                            "desc": summary,
                        })
        except Exception:
            pass
        return cves

    def analyze(self, data):
        issues = []
        score = 100

        critical = [c for c in data["cves"] if str(c.get("score", "")) in ("CRITICAL", "9", "10") or
                    (isinstance(c.get("score"), (int, float)) and float(c["score"]) >= 9.0)]
        high     = [c for c in data["cves"] if c not in critical]

        if critical:
            score -= min(len(critical) * 20, 50)
            for c in critical[:3]:
                issues.append(f"CRITICAL CVE {c['id']} в {c['component']}: {c['desc'][:80]}")

        if high:
            score -= min(len(high) * 10, 30)
            for c in high[:3]:
                issues.append(f"HIGH CVE {c['id']} в {c['component']}: {c['desc'][:80]}")

        if data.get("offline") and not data["cves"] and not data.get("cache_used"):
            issues.append("Offline-режим: нет локального кэша CVE (запустите --update-db с интернетом)")

        status = "OK" if score >= 80 else ("WARNING" if score >= 50 else "CRITICAL")
        return {"score": max(score, 0), "status": status, "issues": issues}

    def report(self, analysis):
        return analysis
