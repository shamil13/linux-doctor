import subprocess
import os
import json
from core.module import Module


class DockerModule(Module):
    name = "Docker"
    weight = 10
    # Если Docker не используется — модуль не должен портить общий балл
    skip_if_absent = True

    def collect(self):
        available = self._docker_available()
        if not available:
            return {"available": False}

        return {
            "available":  True,
            "containers": self._containers(),
            "images":     self._images(),
            "sock_perms": self._socket_perms(),
            "version":    self._version(),
        }

    def _docker_available(self):
        try:
            r = subprocess.run(["docker", "version", "--format", "{{.Server.Version}}"],
                                capture_output=True, text=True, timeout=5)
            return r.returncode == 0 and r.stdout.strip() != ""
        except Exception:
            return False

    def _version(self):
        try:
            r = subprocess.run(["docker", "version", "--format", "{{.Server.Version}}"],
                                capture_output=True, text=True, timeout=5)
            return r.stdout.strip()
        except Exception:
            return None

    def _containers(self):
        containers = []
        try:
            r = subprocess.run(
                ["docker", "ps", "-a", "--format", "{{.ID}}\t{{.Names}}\t{{.Image}}\t{{.Status}}"],
                capture_output=True, text=True, timeout=10
            )
            for line in r.stdout.splitlines():
                parts = line.split("\t")
                if len(parts) < 4:
                    continue
                cid, name, image, status = parts[0], parts[1], parts[2], parts[3]
                info = self._inspect(cid)
                containers.append({
                    "id": cid, "name": name, "image": image, "status": status,
                    "running": status.lower().startswith("up"),
                    "privileged": info.get("privileged", False),
                    "user": info.get("user", ""),
                    "network_mode": info.get("network_mode", ""),
                    "exposed_ports": info.get("exposed_ports", []),
                })
        except Exception:
            pass
        return containers

    def _inspect(self, container_id):
        info = {"privileged": False, "user": "", "network_mode": "", "exposed_ports": []}
        try:
            r = subprocess.run(
                ["docker", "inspect", container_id],
                capture_output=True, text=True, timeout=10
            )
            data = json.loads(r.stdout)
            if data:
                c = data[0]
                host_config = c.get("HostConfig", {})
                info["privileged"]   = host_config.get("Privileged", False)
                info["network_mode"] = host_config.get("NetworkMode", "")
                info["user"]         = c.get("Config", {}).get("User", "")
                ports = c.get("NetworkSettings", {}).get("Ports", {}) or {}
                exposed = []
                for port, bindings in ports.items():
                    if bindings:
                        for b in bindings:
                            host_ip = b.get("HostIp", "")
                            if host_ip in ("0.0.0.0", "::"):
                                exposed.append(port)
                info["exposed_ports"] = exposed
        except Exception:
            pass
        return info

    def _images(self):
        images = []
        try:
            r = subprocess.run(
                ["docker", "images", "--format", "{{.Repository}}:{{.Tag}}"],
                capture_output=True, text=True, timeout=10
            )
            images = [line.strip() for line in r.stdout.splitlines() if line.strip()]
        except Exception:
            pass
        return images

    def _socket_perms(self):
        path = "/var/run/docker.sock"
        result = {"exists": False, "world_writable": False, "group": None}
        try:
            if os.path.exists(path):
                result["exists"] = True
                st = os.stat(path)
                result["world_writable"] = bool(st.st_mode & 0o002)
                import grp
                try:
                    result["group"] = grp.getgrgid(st.st_gid).gr_name
                except Exception:
                    pass
        except Exception:
            pass
        return result

    def analyze(self, data):
        if not data.get("available"):
            return {
                "score": 100, "status": "OK",
                "issues": [], "informational": False,
                "not_applicable": True,
            }

        issues = []
        score = 100

        privileged = [c for c in data["containers"] if c["running"] and c["privileged"]]
        if privileged:
            names = ", ".join(c["name"] for c in privileged)
            issues.append(f"Privileged-контейнеры (полный доступ к хосту): {names}")
            score -= min(len(privileged) * 25, 50)

        root_containers = [
            c for c in data["containers"]
            if c["running"] and (c["user"] in ("", "root", "0"))
        ]
        if root_containers:
            names = ", ".join(c["name"] for c in root_containers[:5])
            issues.append(f"Контейнеры работают от root: {names}")
            score -= min(len(root_containers) * 5, 20)

        sock = data["sock_perms"]
        if sock["exists"] and sock["world_writable"]:
            issues.append("docker.sock доступен на запись всем (world-writable) — эквивалент root на хосте")
            score -= 30

        latest = [c for c in data["containers"] if c["image"].endswith(":latest")]
        if latest:
            issues.append(f"Контейнеры на теге 'latest' (непредсказуемые обновления): {len(latest)}")
            score -= 5

        host_net = [c for c in data["containers"] if c["running"] and c["network_mode"] == "host"]
        if host_net:
            names = ", ".join(c["name"] for c in host_net)
            issues.append(f"Контейнеры в network_mode=host (полный доступ к сети хоста): {names}")
            score -= 15

        status = "OK" if score >= 80 else ("WARNING" if score >= 50 else "CRITICAL")
        return {"score": max(score, 0), "status": status, "issues": issues}

    def report(self, analysis):
        return analysis
