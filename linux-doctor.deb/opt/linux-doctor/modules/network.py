import psutil
import subprocess
import os
from core.module import Module


class NetworkModule(Module):
    name = "Network"
    weight = 15

    def collect(self):
        return {
            "open_ports":  self._open_ports(),
            "connections": self._suspicious_connections(),
            "interfaces":  self._interfaces(),
            "routes":      self._routes(),
            "dns":         self._dns(),
            "ntp":         self._ntp(),
        }

    def _open_ports(self):
        ports = []
        try:
            for conn in psutil.net_connections(kind="inet"):
                if conn.status == "LISTEN" and conn.laddr:
                    ports.append(conn.laddr.port)
        except Exception:
            pass
        return sorted(set(ports))

    def _suspicious_connections(self):
        suspicious = []
        RISKY_PORTS = {23, 21, 3389, 5900, 4444, 1337}
        try:
            for conn in psutil.net_connections(kind="inet"):
                if conn.raddr and conn.raddr.port in RISKY_PORTS:
                    suspicious.append(f"{conn.raddr.ip}:{conn.raddr.port}")
        except Exception:
            pass
        return suspicious

    def _interfaces(self):
        stats = {}
        try:
            for iface, addrs in psutil.net_if_addrs().items():
                if iface == "lo":
                    continue
                io = psutil.net_io_counters(pernic=True).get(iface)
                if io:
                    stats[iface] = {
                        "bytes_sent_mb": round(io.bytes_sent / 1024 / 1024, 1),
                        "bytes_recv_mb": round(io.bytes_recv / 1024 / 1024, 1),
                        "errors": io.errin + io.errout,
                        "drops": io.dropin + io.dropout,
                    }
        except Exception:
            pass
        return stats

    def _routes(self):
        """Таблица маршрутизации через `ip route`."""
        routes = []
        default_count = 0
        try:
            r = subprocess.run(
                ["ip", "-4", "route", "show"],
                capture_output=True, text=True, timeout=5
            )
            for line in r.stdout.splitlines():
                line = line.strip()
                if not line:
                    continue
                routes.append(line)
                if line.startswith("default"):
                    default_count += 1
        except Exception:
            pass

        v6_routes = []
        try:
            r = subprocess.run(
                ["ip", "-6", "route", "show"],
                capture_output=True, text=True, timeout=5
            )
            for line in r.stdout.splitlines():
                line = line.strip()
                if line:
                    v6_routes.append(line)
        except Exception:
            pass

        return {"v4": routes, "v6": v6_routes, "default_count": default_count}

    def _dns(self):
        """Резолверы из /etc/resolv.conf."""
        resolvers = []
        search = []
        try:
            with open("/etc/resolv.conf") as f:
                for line in f:
                    line = line.strip()
                    if line.startswith("nameserver"):
                        parts = line.split()
                        if len(parts) >= 2:
                            resolvers.append(parts[1])
                    elif line.startswith("search"):
                        search = line.split()[1:]
        except Exception:
            pass
        return {"resolvers": resolvers, "search": search}

    def _ntp(self):
        """Статус синхронизации времени (timedatectl / chronyc)."""
        result = {"synced": None, "service": None, "offset": None}
        try:
            r = subprocess.run(
                ["timedatectl", "show", "-p", "NTPSynchronized", "--value"],
                capture_output=True, text=True, timeout=5
            )
            val = r.stdout.strip().lower()
            if val in ("yes", "no"):
                result["synced"]  = (val == "yes")
                result["service"] = "systemd-timesyncd"
        except Exception:
            pass

        if result["synced"] is None:
            try:
                r = subprocess.run(
                    ["chronyc", "tracking"],
                    capture_output=True, text=True, timeout=5
                )
                if r.returncode == 0:
                    result["service"] = "chronyd"
                    for line in r.stdout.splitlines():
                        if "Leap status" in line:
                            result["synced"] = "Normal" in line
                        if "System time" in line:
                            result["offset"] = line.split(":", 1)[1].strip()
            except Exception:
                pass

        return result

    def analyze(self, data):
        issues = []
        score = 100

        if data.get("connections"):
            issues.append(f"Подозрительные соединения: {', '.join(data['connections'])}")
            score -= 40

        for iface, s in data["interfaces"].items():
            if s["errors"] > 100:
                issues.append(f"{iface}: {s['errors']} ошибок сети")
                score -= 10
            if s["drops"] > 100:
                issues.append(f"{iface}: {s['drops']} потерянных пакетов")
                score -= 10

        if len(data["open_ports"]) > 20:
            issues.append(f"Много открытых портов: {len(data['open_ports'])}")
            score -= 10

        routes = data.get("routes", {})
        if routes.get("default_count", 0) == 0:
            issues.append("Нет маршрута по умолчанию (default route)")
            score -= 15
        elif routes.get("default_count", 0) > 1:
            issues.append(f"Несколько default route ({routes['default_count']}) — возможна нестабильная маршрутизация")
            score -= 5

        dns = data.get("dns", {})
        if not dns.get("resolvers"):
            issues.append("Нет настроенных DNS-резолверов в /etc/resolv.conf")
            score -= 15

        ntp = data.get("ntp", {})
        if ntp.get("synced") is False:
            issues.append(f"Время не синхронизировано ({ntp.get('service', 'NTP')})")
            score -= 15
        elif ntp.get("synced") is None:
            issues.append("Не удалось определить статус синхронизации времени (NTP)")
            score -= 5

        status = "OK" if score >= 80 else ("WARNING" if score >= 50 else "CRITICAL")
        return {"score": max(score, 0), "status": status, "issues": issues}

    def report(self, analysis):
        return analysis
