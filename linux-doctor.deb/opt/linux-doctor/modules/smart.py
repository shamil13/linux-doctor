import subprocess
import re
import os
from core.module import Module


class SmartModule(Module):
    name = "S.M.A.R.T"
    weight = 15

    CRITICAL_ATTRS = {
        "5":   "Reallocated Sectors",
        "10":  "Spin Retry Count",
        "184": "End-to-End Error",
        "187": "Uncorrectable Errors",
        "188": "Command Timeout",
        "196": "Reallocated Event Count",
        "197": "Pending Sectors",
        "198": "Uncorrectable Sector Count",
        "199": "UDMA CRC Errors",
    }

    def collect(self):
        disks = self._find_disks()
        results = {}
        for disk in disks:
            results[disk] = self._check_disk(disk)
        return {"disks": results, "smartctl_available": self._smartctl_available()}

    def _smartctl_available(self):
        try:
            subprocess.run(["smartctl", "--version"], capture_output=True, timeout=5)
            return True
        except Exception:
            return False

    def _find_disks(self):
        disks = []
        try:
            r = subprocess.run(
                ["lsblk", "-dno", "NAME,TYPE"],
                capture_output=True, text=True, timeout=5
            )
            for line in r.stdout.splitlines():
                parts = line.split()
                if len(parts) == 2 and parts[1] in ("disk",):
                    disks.append(f"/dev/{parts[0]}")
        except Exception:
            pass
        return disks[:4]  # максимум 4 диска

    def _check_disk(self, disk):
        result = {
            "health": "UNKNOWN",
            "temperature": None,
            "power_on_hours": None,
            "critical_attrs": {},
            "errors": [],
        }
        try:
            r = subprocess.run(
                ["smartctl", "-A", "-H", disk],
                capture_output=True, text=True, timeout=10
            )
            output = r.stdout

            # Общее состояние
            if "PASSED" in output:
                result["health"] = "PASSED"
            elif "FAILED" in output:
                result["health"] = "FAILED"

            # Парсим атрибуты
            for line in output.splitlines():
                parts = line.split()
                if len(parts) < 10:
                    continue
                attr_id = parts[0]
                try:
                    raw_val = int(parts[-1])
                except Exception:
                    continue

                # Температура
                if attr_id == "194" and raw_val > 0:
                    result["temperature"] = raw_val & 0xFF

                # Power on hours
                if attr_id == "9":
                    result["power_on_hours"] = raw_val

                # Критичные атрибуты
                if attr_id in self.CRITICAL_ATTRS and raw_val > 0:
                    result["critical_attrs"][self.CRITICAL_ATTRS[attr_id]] = raw_val

        except Exception as e:
            result["errors"].append(str(e))
        return result

    def analyze(self, data):
        issues = []
        score = 100

        if not data["smartctl_available"]:
            return {
                "score": 50,
                "status": "WARNING",
                "issues": ["smartctl не установлен (apt install smartmontools)"],
            }

        for disk, info in data["disks"].items():
            if info["health"] == "FAILED":
                issues.append(f"{disk}: SMART FAILED — диск скоро выйдет из строя!")
                score -= 50

            for attr, val in info["critical_attrs"].items():
                issues.append(f"{disk}: {attr} = {val} (должно быть 0)")
                score -= 15

            temp = info.get("temperature")
            if temp and temp > 55:
                issues.append(f"{disk}: температура {temp}°C (критично > 55°C)")
                score -= 20
            elif temp and temp > 45:
                issues.append(f"{disk}: температура {temp}°C (высокая > 45°C)")
                score -= 10

            hours = info.get("power_on_hours")
            if hours and hours > 43800:  # 5 лет
                issues.append(f"{disk}: наработка {hours//8760:.0f} лет — рекомендуется замена")
                score -= 10

        status = "OK" if score >= 80 else ("WARNING" if score >= 50 else "CRITICAL")
        return {"score": max(score, 0), "status": status, "issues": issues}

    def report(self, analysis):
        return analysis
