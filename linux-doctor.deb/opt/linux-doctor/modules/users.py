import subprocess
import os
from core.module import Module


class UsersModule(Module):
    name = "Users"
    weight = 15

    def collect(self):
        return {
            "uid0":          self._uid0_users(),
            "empty_passwords": self._empty_passwords(),
            "sudoers":       self._sudoers_analysis(),
            "ssh_keys":      self._check_ssh_keys(),
            "last_logins":   self._last_logins(),
            "locked_root":   self._root_locked(),
        }

    def _uid0_users(self):
        found = []
        try:
            with open("/etc/passwd") as f:
                for line in f:
                    p = line.strip().split(":")
                    if len(p) >= 4 and p[2] == "0" and p[0] != "root":
                        found.append(p[0])
        except Exception:
            pass
        return found

    def _empty_passwords(self):
        found = []
        try:
            with open("/etc/shadow") as f:
                for line in f:
                    p = line.strip().split(":")
                    if len(p) >= 2 and p[1] == "":
                        found.append(p[0])
        except Exception:
            pass
        return found

    def _sudoers_analysis(self):
        result = {"nopasswd": [], "all_commands": []}
        paths = ["/etc/sudoers"]
        if os.path.exists("/etc/sudoers.d"):
            paths += [f"/etc/sudoers.d/{f}" for f in os.listdir("/etc/sudoers.d")]
        for path in paths:
            try:
                with open(path) as f:
                    for line in f:
                        line = line.strip()
                        if line.startswith("#") or not line:
                            continue
                        if "NOPASSWD" in line:
                            result["nopasswd"].append(line)
                        if "ALL=(ALL)" in line or "ALL=(ALL:ALL)" in line:
                            result["all_commands"].append(line)
            except Exception:
                pass
        return result

    def _check_ssh_keys(self):
        weak = []
        home_base = "/home"
        users_dirs = ["/root"] + [
            os.path.join(home_base, u)
            for u in (os.listdir(home_base) if os.path.exists(home_base) else [])
        ]
        WEAK_ALGOS = ("ssh-dss", "ecdsa-sha2-nistp256", "ssh-rsa")
        for user_dir in users_dirs:
            auth_keys = os.path.join(user_dir, ".ssh", "authorized_keys")
            if os.path.exists(auth_keys):
                try:
                    with open(auth_keys) as f:
                        for line in f:
                            line = line.strip()
                            if not line or line.startswith("#"):
                                continue
                            algo = line.split()[0] if line else ""
                            if algo in WEAK_ALGOS:
                                weak.append(f"{auth_keys}: {algo}")
                except Exception:
                    pass
        return weak

    def _last_logins(self):
        logins = []
        try:
            r = subprocess.run(
                ["last", "-n", "5", "-F"],
                capture_output=True, text=True, timeout=5
            )
            for line in r.stdout.splitlines()[:5]:
                if line.strip() and not line.startswith("wtmp"):
                    logins.append(line.strip())
        except Exception:
            pass
        return logins

    def _root_locked(self):
        try:
            r = subprocess.run(
                ["passwd", "-S", "root"],
                capture_output=True, text=True, timeout=5
            )
            return "L" in r.stdout or "locked" in r.stdout.lower()
        except Exception:
            return False

    def analyze(self, data):
        issues = []
        score = 100

        for u in data["uid0"]:
            issues.append(f"Пользователь {u!r} имеет UID 0 (root-права)")
            score -= 30

        for u in data["empty_passwords"]:
            issues.append(f"Пустой пароль у пользователя {u!r}")
            score -= 25

        for line in data["sudoers"]["nopasswd"][:3]:
            issues.append(f"sudo NOPASSWD: {line[:80]}")
            score -= 10

        for key in data["ssh_keys"][:3]:
            issues.append(f"Слабый SSH-ключ: {key}")
            score -= 10

        status = "OK" if score >= 80 else ("WARNING" if score >= 50 else "CRITICAL")
        return {"score": max(score, 0), "status": status, "issues": issues}

    def report(self, analysis):
        return analysis
