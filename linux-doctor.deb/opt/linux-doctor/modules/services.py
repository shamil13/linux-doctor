import subprocess
from collections import Counter
from core.module import Module


class ServiceModule(Module):
    name = "Services"
    weight = 10

    # Критичные — штрафуем только если установлены И не активны
    # На Kali может использоваться ssh или sshd (зависит от версии)
    CRITICAL_ANY_OF = [["ssh", "sshd"]]  # достаточно одного из списка
    OPTIONAL = ["ufw", "fail2ban", "auditd", "apparmor", "cron", "crond"]

    def collect(self):
        all_units = self._all_units()
        return {
            "all_units":      all_units,
            "by_state":       self._group_by_state(all_units),
            "failed":         [u["name"] for u in all_units if u["sub"] == "failed"],
            "important_down": self._check_important(),
        }

    def _all_units(self):
        units = []
        try:
            r = subprocess.run(
                ["systemctl", "list-units", "--type=service",
                 "--all", "--no-legend", "--no-pager", "--plain"],
                capture_output=True, text=True, timeout=15
            )
            for raw_line in r.stdout.splitlines():
                line = raw_line.strip()
                if not line:
                    continue
                if line.startswith("●"):
                    line = line[1:].strip()
                parts = line.split(None, 4)
                if len(parts) < 4:
                    continue
                name, load_state, active_state, sub_state = parts[0], parts[1], parts[2], parts[3]
                desc = parts[4] if len(parts) > 4 else ""
                units.append({
                    "name": name,
                    "load": load_state,
                    "active": active_state,
                    "sub": sub_state,
                    "description": desc,
                })
        except Exception:
            pass
        return units

    def _group_by_state(self, units):
        counter = Counter()
        groups = {"running": [], "exited": [], "dead": [], "failed": [], "other": []}
        for u in units:
            sub = u["sub"]
            counter[sub] += 1
            if sub == "running":
                groups["running"].append(u["name"])
            elif sub == "exited":
                groups["exited"].append(u["name"])
            elif sub == "dead":
                groups["dead"].append(u["name"])
            elif sub == "failed":
                groups["failed"].append(u["name"])
            else:
                groups["other"].append(u["name"])
        return {"counts": dict(counter), "groups": groups}

    def _check_important(self):
        """Проверяем сервисы. Опциональные — только если установлены."""
        down = []

        # Группы "хотя бы один должен быть активен"
        for group in self.CRITICAL_ANY_OF:
            statuses = [self._is_active(svc) for svc in group]
            if any(s is True for s in statuses):
                continue  # хотя бы один активен — OK
            if all(s is None for s in statuses):
                continue  # ни один не установлен — не штрафуем
            # Установлен но не активен
            installed = [group[i] for i, s in enumerate(statuses) if s is not None]
            if installed:
                down.append(installed[0])

        # Опциональные — штрафуем только если установлен но не активен
        for svc in self.OPTIONAL:
            status = self._is_active(svc)
            if status is False:
                down.append(svc)

        return down

    def _is_active(self, svc):
        """Возвращает True=active, False=inactive/failed, None=not found."""
        try:
            r = subprocess.run(
                ["systemctl", "is-active", svc],
                capture_output=True, text=True, timeout=5
            )
            status = r.stdout.strip()
            if status in ("active", "activating"):
                return True
            if status == "inactive" and r.returncode != 0:
                # Различаем "не установлен" от "установлен но не запущен"
                r2 = subprocess.run(
                    ["systemctl", "status", svc],
                    capture_output=True, text=True, timeout=5
                )
                if "could not be found" in r2.stderr or r2.returncode == 4:
                    return None  # не установлен
            return False
        except Exception:
            return None

    def analyze(self, data):
        issues = []
        score = 100

        if data["failed"]:
            names = ", ".join(data["failed"][:5])
            issues.append(f"Упавшие сервисы: {names}")
            score -= min(len(data["failed"]) * 15, 45)

        if data["important_down"]:
            names = ", ".join(data["important_down"])
            issues.append(f"Сервисы не активны: {names}")
            score -= min(len(data["important_down"]) * 10, 30)

        status = "OK" if score >= 80 else ("WARNING" if score >= 50 else "CRITICAL")
        return {"score": max(score, 0), "status": status, "issues": issues}

    def report(self, analysis):
        return analysis
