import re
import os
from collections import Counter
from core.module import Module

class LogModule(Module):
    name = "Logs"
    weight = 10

    LOG_FILES = [
        "/var/log/auth.log",
        "/var/log/secure",
        "/var/log/syslog",
        "/var/log/messages",
    ]

    def collect(self):
        data = {
            "bruteforce": [],
            "critical_errors": [],
            "oom_kills": [],
            "failed_logins": 0,
            "sudo_attempts": [],
        }

        for path in self.LOG_FILES:
            if os.path.exists(path):
                try:
                    with open(path, "r", errors="ignore") as f:
                        lines = f.readlines()[-2000:]  # последние 2000 строк
                    self._parse(lines, data)
                except PermissionError:
                    data["critical_errors"].append(f"Нет доступа к {path}")

        return data

    def _parse(self, lines, data):
        failed_ips = Counter()
        for line in lines:
            ll = line.lower()

            # Брутфорс SSH
            if "failed password" in ll or "invalid user" in ll:
                data["failed_logins"] += 1
                m = re.search(r"from (\d+\.\d+\.\d+\.\d+)", line)
                if m:
                    failed_ips[m.group(1)] += 1

            # OOM killer
            if "oom" in ll and "kill" in ll:
                data["oom_kills"].append(line.strip()[-120:])

            # Критичные ошибки ядра
            if "kernel: " in ll and ("error" in ll or "bug:" in ll or "oops" in ll):
                data["critical_errors"].append(line.strip()[-120:])

            # sudo
            if "sudo:" in ll and ("incorrect password" in ll or "authentication failure" in ll):
                m = re.search(r"sudo:\s+(\w+)", line)
                if m:
                    data["sudo_attempts"].append(m.group(1))

        # Топ атакующих IP
        data["bruteforce"] = [
            {"ip": ip, "attempts": cnt}
            for ip, cnt in failed_ips.most_common(5)
            if cnt >= 5
        ]

    def analyze(self, data):
        issues = []
        score = 100

        if data["bruteforce"]:
            top = data["bruteforce"][0]
            issues.append(f"Брутфорс SSH: {top['ip']} — {top['attempts']} попыток")
            score -= 30

        if data["failed_logins"] > 50:
            issues.append(f"Много неудачных входов: {data['failed_logins']}")
            score -= 20

        if data["oom_kills"]:
            issues.append(f"OOM killer сработал {len(data['oom_kills'])} раз")
            score -= 25

        if len(data["critical_errors"]) > 5:
            issues.append(f"Критичных ошибок в логах: {len(data['critical_errors'])}")
            score -= 15

        status = "OK" if score >= 80 else ("WARNING" if score >= 50 else "CRITICAL")
        return {"score": max(score, 0), "status": status, "issues": issues}

    def report(self, analysis):
        return analysis
