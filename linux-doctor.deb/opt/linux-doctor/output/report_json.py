import json
from datetime import datetime

def generate(results, diag, context, history):
    return json.dumps({
        "generated": datetime.now().isoformat(),
        "total_score": round(sum(s for _, s in results) / len(results)),
        "modules": {
            name: {
                "score": score,
                "status": context.analysis.get(name.lower(), {}).get("status"),
                "issues": context.analysis.get(name.lower(), {}).get("issues", []),
                "raw": context.raw_data.get(name.lower(), {}),
            }
            for name, score in results
        },
        "diagnosis": diag,
        "history": history[-10:],
    }, indent=2, ensure_ascii=False)
