import json
from rich.console import Console
from rich.table import Table
from rich import box

console = Console()


def compare_reports(path1, path2):
    try:
        with open(path1) as f:
            r1 = json.load(f)
        with open(path2) as f:
            r2 = json.load(f)
    except Exception as e:
        console.print(f"[red]Ошибка чтения файлов: {e}[/]")
        return

    t = Table(title=f"Diff: {path1} → {path2}", box=box.ROUNDED)
    t.add_column("Модуль",   style="bold")
    t.add_column("Было",     justify="center")
    t.add_column("Стало",    justify="center")
    t.add_column("Изменение", justify="center")

    m1 = r1.get("modules", {})
    m2 = r2.get("modules", {})
    all_modules = sorted(set(list(m1.keys()) + list(m2.keys())))

    for mod in all_modules:
        s1 = m1.get(mod, {}).get("score", "—")
        s2 = m2.get(mod, {}).get("score", "—")
        if s1 == "—" or s2 == "—":
            diff_str = "[dim]нет данных[/]"
        else:
            diff = s2 - s1
            if diff > 0:
                diff_str = f"[green]+{diff}[/]"
            elif diff < 0:
                diff_str = f"[red]{diff}[/]"
            else:
                diff_str = "[dim]=[/]"

        sc1_col = "green" if isinstance(s1, int) and s1 >= 80 else ("yellow" if isinstance(s1, int) and s1 >= 60 else "red")
        sc2_col = "green" if isinstance(s2, int) and s2 >= 80 else ("yellow" if isinstance(s2, int) and s2 >= 60 else "red")
        t.add_row(mod, f"[{sc1_col}]{s1}[/]", f"[{sc2_col}]{s2}[/]", diff_str)

    # Итог
    ts1 = r1.get("total_score", "—")
    ts2 = r2.get("total_score", "—")
    total_diff = ts2 - ts1 if isinstance(ts1, int) and isinstance(ts2, int) else "—"
    diff_str = (f"[green]+{total_diff}[/]" if isinstance(total_diff, int) and total_diff > 0
                else (f"[red]{total_diff}[/]" if isinstance(total_diff, int) and total_diff < 0
                      else "[dim]=[/]"))
    t.add_row("[bold]ИТОГО[/]", f"[bold]{ts1}[/]", f"[bold]{ts2}[/]", diff_str)

    console.print(t)
    console.print(f"\n  Отчёт 1: {r1.get('generated', '?')}")
    console.print(f"  Отчёт 2: {r2.get('generated', '?')}")
