import requests
import json
import socket
from datetime import datetime


def send_report(url, report_json_str, token=None, timeout=15):
    """Отправить полный JSON-отчёт на удалённый сервер (POST)."""
    try:
        payload = json.loads(report_json_str)
    except Exception:
        payload = {"raw": report_json_str}

    payload["agent"] = {
        "hostname": socket.gethostname(),
        "sent_at":  datetime.now().isoformat(),
    }

    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    try:
        r = requests.post(url, json=payload, headers=headers, timeout=timeout)
        return r.status_code < 300, f"HTTP {r.status_code}"
    except Exception as e:
        return False, str(e)
