import json
from datetime import datetime

def generate(results, diag, context, history):
    total = round(sum(s for _, s in results) / len(results))
    color = "#22c55e" if total >= 80 else ("#f59e0b" if total >= 60 else "#ef4444")

    rows = ""
    for name, score in results:
        sc = "#22c55e" if score >= 80 else ("#f59e0b" if score >= 60 else "#ef4444")
        issues = context.analysis.get(name.lower(), {}).get("issues", [])
        issues_html = "".join(f"<li>{i}</li>" for i in issues) or "<li>Нет проблем</li>"
        rows += f"""
        <tr>
          <td><b>{name}</b></td>
          <td><span style="color:{sc};font-weight:bold">{score}</span></td>
          <td><ul>{issues_html}</ul></td>
        </tr>"""

    problems_html = "".join(f"<li>{p}</li>" for p in diag["problems"]) or "<li>Не обнаружено</li>"
    suggestions_html = "".join(f"<li>{s}</li>" for s in diag["suggestions"])

    chart_labels = json.dumps([h["ts"][11:16] for h in history[-20:]])
    chart_data   = json.dumps([h["score"] for h in history[-20:]])

    chart_section = ""
    if len(history) >= 2:
        chart_section = f"""
<h2>История score</h2>
<div class="card" style="max-width:700px">
  <canvas id="chart"></canvas>
</div>
<script>
new Chart(document.getElementById("chart"), {{
  type: "line",
  data: {{
    labels: {chart_labels},
    datasets: [{{ label: "Score", data: {chart_data},
      borderColor: "#7dd3fc", backgroundColor: "rgba(125,211,252,0.1)",
      tension: 0.3, fill: true }}]
  }},
  options: {{ scales: {{ y: {{ min: 0, max: 100 }} }}, plugins: {{ legend: {{ display: false }} }} }}
}});
</script>"""

    return f"""<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<title>Linux Doctor Report</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
  body {{ font-family: 'Segoe UI', sans-serif; background:#0f172a; color:#e2e8f0; margin:0; padding:24px; }}
  h1 {{ color:#7dd3fc; }} h2 {{ color:#94a3b8; border-bottom:1px solid #334155; padding-bottom:6px; }}
  .score-box {{ display:inline-block; background:#1e293b; border-radius:16px; padding:24px 40px;
               font-size:64px; font-weight:bold; color:{color}; margin:16px 0; }}
  table {{ width:100%; border-collapse:collapse; background:#1e293b; border-radius:12px; overflow:hidden; }}
  th {{ background:#334155; padding:10px 16px; text-align:left; }}
  td {{ padding:10px 16px; border-bottom:1px solid #334155; vertical-align:top; }}
  ul {{ margin:4px 0; padding-left:16px; }}
  .card {{ background:#1e293b; border-radius:12px; padding:20px; margin:16px 0; }}
  .ts {{ color:#64748b; font-size:13px; }}
</style>
</head>
<body>
<h1>Linux Doctor — Отчёт</h1>
<p class="ts">Сгенерировано: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
<h2>Общий балл</h2>
<div class="score-box">{total}/100</div>
<h2>Модули</h2>
<table>
  <tr><th>Модуль</th><th>Score</th><th>Проблемы</th></tr>
  {rows}
</table>
<h2>Проблемы</h2>
<div class="card"><ul>{problems_html}</ul></div>
<h2>Рекомендации</h2>
<div class="card"><ul>{suggestions_html}</ul></div>
{chart_section}
</body></html>"""
