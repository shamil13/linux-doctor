import typer
import os
from typing import Optional
from concurrent.futures import ThreadPoolExecutor, as_completed
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.panel import Panel
from rich import box

from core.registry import get_modules
from core.context import SystemContext
from intelligence.diagnoser import Diagnoser
from storage.history import save as history_save, load_all as history_load
from storage import changelog as changelog_store
from output import report_html, report_json
from config.loader import load as load_config
from modules.cve import CVEModule
from modules.logs import LogModule

app = typer.Typer(invoke_without_command=True)
console = Console()


def _collect_raw(name):
    """Собрать raw_data одного модуля без запуска полной диагностики."""
    # Импортируем только нужный класс напрямую, не загружая все модули
    MODULE_MAP = {
        "sysinfo":   ("modules.sysinfo",  "SysInfoModule"),
        "services":  ("modules.services", "ServiceModule"),
        "network":   ("modules.network",  "NetworkModule"),
        "docker":    ("modules.docker",   "DockerModule"),
        "users":     ("modules.users",    "UsersModule"),
        "logs":      ("modules.logs",     "LogModule"),
        "cpu":       ("modules.cpu",      "CPUModule"),
        "memory":    ("modules.memory",   "MemoryModule"),
        "disk":      ("modules.disk",     "DiskModule"),
        "hardware":  ("modules.hardware", "HardwareModule"),
        "security":  ("modules.security", "SecurityModule"),
        "process":   ("modules.process",  "ProcessModule"),
        "updates":   ("modules.updates",  "UpdateModule"),
        "cve":       ("modules.cve",      "CVEModule"),
        "hardening": ("modules.hardening","HardeningModule"),
        "s.m.a.r.t": ("modules.smart",   "SmartModule"),
        "rootkit":   ("modules.rootkit",  "RootkitModule"),
    }
    key = name.lower()
    if key not in MODULE_MAP:
        console.print(f"[red]Модуль {name!r} не найден.[/]")
        return {}
    mod_path, cls_name = MODULE_MAP[key]
    try:
        import importlib
        mod = importlib.import_module(mod_path)
        cls = getattr(mod, cls_name)
        return cls().collect()
    except Exception as e:
        console.print(f"[red]Ошибка модуля {name}: {e}[/]")
        return {}


def run_diagnosis(verbose=False, disabled=None, only=None):
    cfg     = load_config()
    modules = get_modules(disabled=disabled or cfg["modules"]["disabled"])
    if only:
        modules = [m for m in modules if m.name.lower() == only.lower()]
        if not modules:
            console.print(f"[red]Модуль {only!r} не найден.[/]")
            raise typer.Exit()
    context = SystemContext()
    results = []

    table = Table(box=box.ROUNDED, show_header=True, header_style="bold cyan")
    table.add_column("Модуль",  style="bold", width=12)
    table.add_column("Score",   justify="center", width=7)
    table.add_column("Статус",  width=10)
    table.add_column("Значения / Детали")

    def _run_module(m):
        try:
            data     = m.collect()
            analysis = m.analyze(data)
        except Exception as e:
            data     = {}
            analysis = {"score": 0, "status": "CRITICAL", "issues": [f"Ошибка модуля: {e}"]}
        return m, data, analysis

    with Progress(SpinnerColumn(), TextColumn("[cyan]{task.description}"), transient=True) as p:
        task = p.add_task("Диагностика...", total=len(modules))
        p.update(task, description="Запускаю модули параллельно...")
        with ThreadPoolExecutor(max_workers=min(8, len(modules) or 1)) as pool:
            futures = {pool.submit(_run_module, m): m for m in modules}
            for fut in as_completed(futures):
                m, data, analysis = fut.result()
                context.raw_data[m.name.lower()] = data
                context.analysis[m.name.lower()] = analysis
                results.append((m.name, analysis["score"]))
                p.advance(task)

    # Сохраняем исходный порядок модулей для вывода
    order = {m.name.lower(): i for i, m in enumerate(modules)}
    results.sort(key=lambda r: order[r[0].lower()])

    for m in modules:
        name   = m.name
        data   = context.raw_data.get(name.lower(), {})
        anal   = context.analysis.get(name.lower(), {})
        score  = anal.get("score", 0)
        status = anal.get("status", "CRITICAL")
        if anal.get("informational"):
            icon = "[dim]ℹ️  INFO[/]"
            sc = "dim"
        else:
            icon = {
                "OK":       "[green]✅ OK[/]",
                "WARNING":  "[yellow]⚠️  WARN[/]",
                "CRITICAL": "[red]❌ CRIT[/]",
            }.get(status, status)
            sc = "green" if score >= 80 else ("yellow" if score >= 60 else "red")
        extra = _extra(name.lower(), data, anal, verbose)
        table.add_row(name, f"[{sc}]{'—' if anal.get('informational') else score}[/]", icon, extra)

    scored = [(n, s) for n, s in results if not context.analysis.get(n.lower(), {}).get("informational")]
    if scored:
        total = round(sum(s for _, s in scored) / len(scored))
        tc = "green" if total >= 80 else ("yellow" if total >= 60 else "red")
        subtitle = f"[{tc}]Общий балл: {total}/100[/]"
    else:
        total = None
        subtitle = "[dim]Информационный модуль[/]"
    console.print()
    console.print(Panel(
        table,
        title="[bold cyan]🩺 Linux Doctor[/]",
        subtitle=subtitle
    ))
    return scored, context, total


def _extra(name, data, anal, verbose):
    parts = []
    if name == "cpu":
        parts.append(f"cpu={data.get('usage','?')}%")
    elif name == "memory":
        parts.append(f"ram={data.get('usage','?')}%")
    elif name == "disk":
        parts.append(f"disk={data.get('usage','?')}%")
    elif name == "hardware":
        temps = data.get("temps", {})
        if temps:
            max_t = max(temps.values())
            col = "red" if max_t > 70 else ("yellow" if max_t > 55 else "green")
            parts.append(f"[{col}]temp={max_t}°C[/]")
        ent = data.get("entropy")
        if ent:
            col = "red" if ent["available"] < 100 else ("yellow" if ent["available"] < 500 else "green")
            parts.append(f"[{col}]entropy={ent['available']}[/]")
        load = data.get("load")
        if load:
            parts.append(f"load={load['1min']}")
        up = data.get("uptime")
        if up:
            parts.append(f"up={up}")
    elif name == "security":
        flags = []
        if data.get("ssh_password"): flags.append("[yellow]ssh:passwd[/]")
        if data.get("root_login"):   flags.append("[yellow]root:yes[/]")
        if not data.get("firewall"): flags.append("[yellow]fw:off[/]")
        parts = flags if flags else ["[green]all clear[/]"]
    elif name == "users":
        if data.get("uid0"):      parts.append(f"[red]uid0={len(data['uid0'])}[/]")
        if data.get("empty_passwords"): parts.append(f"[red]empty_pw={len(data['empty_passwords'])}[/]")
        nopasswd = data.get("sudoers", {}).get("nopasswd", [])
        if nopasswd: parts.append(f"[yellow]nopasswd={len(nopasswd)}[/]")
        if not parts: parts.append("[green]ok[/]")
    elif name == "network":
        parts.append(f"ports={len(data.get('open_ports', []))}")
        if data.get("connections"):
            parts.append(f"[red]suspicious={len(data['connections'])}[/]")
        ntp = data.get("ntp", {})
        if ntp.get("synced") is False:
            parts.append("[red]ntp:unsynced[/]")
        if not data.get("dns", {}).get("resolvers"):
            parts.append("[yellow]dns:none[/]")
    elif name == "process":
        parts.append(f"total={data.get('total','?')}")
        if data.get("zombies"):
            parts.append(f"[red]zombies={len(data['zombies'])}[/]")
    elif name == "logs":
        if data.get("bruteforce"):
            parts.append(f"[red]bruteforce={len(data['bruteforce'])} IPs[/]")
        if data.get("failed_logins"):
            parts.append(f"failed={data['failed_logins']}")
    elif name == "updates":
        sec  = data.get("security_updates", 0)
        days = data.get("last_update_days")
        if sec:  parts.append(f"[yellow]sec={sec}[/]")
        if days is not None:
            col = "yellow" if days > 30 else "green"
            parts.append(f"[{col}]last={days}d[/]")
    elif name == "cve":
        cves = data.get("cves", [])
        if cves: parts.append(f"[red]cves={len(cves)}[/]")
        else:    parts.append("[green]no CVEs[/]")
    elif name == "services":
        failed = data.get("failed", [])
        parts.append(f"[red]failed={len(failed)}[/]" if failed else "[green]all up[/]")
    elif name == "hardening":
        sb = sum(1 for v in data.get("sysctl", {}).values() if not v["ok"])
        shb = sum(1 for v in data.get("ssh", {}).values() if not v["ok"])
        mac = data.get("apparmor", {})
        if sb:  parts.append(f"[yellow]sysctl={sb}✗[/]")
        if shb: parts.append(f"[yellow]ssh={shb}✗[/]")
        if not (mac.get("apparmor") or mac.get("selinux")): parts.append("[yellow]MAC:off[/]")
        if not parts: parts.append("[green]hardened[/]")
    elif name == "s.m.a.r.t":
        for disk, info in data.get("disks", {}).items():
            h = info.get("health", "?")
            col = "green" if h == "PASSED" else "red"
            t = info.get("temperature")
            temp_str = f" {t}°C" if t else ""
            parts.append(f"[{col}]{disk}:{h}{temp_str}[/]")
        if not data.get("smartctl_available"):
            parts.append("[dim]smartctl не установлен[/]")
    elif name == "docker":
        if not data.get("available"):
            parts.append("[dim]не установлен[/]")
        else:
            containers = data.get("containers", [])
            running = [c for c in containers if c["running"]]
            priv = [c for c in running if c["privileged"]]
            parts.append(f"containers={len(running)}/{len(containers)}")
            if priv:
                parts.append(f"[red]privileged={len(priv)}[/]")
            sock = data.get("sock_perms", {})
            if sock.get("world_writable"):
                parts.append("[red]sock:world-writable[/]")
    elif name == "rootkit":
        suspicious = (
            len(data.get("known_files", [])) +
            len(data.get("hidden_in_dev", [])) +
            len(data.get("passwd_anomalies", [])) +
            len(data.get("suspicious_procs", []))
        )
        if suspicious: parts.append(f"[red]suspicious={suspicious}[/]")
        else:          parts.append("[green]clean[/]")

    detail = ""
    if verbose and anal.get("issues"):
        detail = "\n  " + "\n  ".join(f"[dim]→ {i}[/]" for i in anal["issues"])

    return (" | ".join(parts) if parts else "[dim]—[/]") + detail


@app.callback(invoke_without_command=True)
def main(
    verbose:  bool = typer.Option(False, "--verbose", "-v", help="Подробный вывод"),
    output:   str  = typer.Option("",   "--output",  "-o", help="Отчёт: report.html / report.json"),
    fix:      bool = typer.Option(False, "--fix",           help="Автоисправление security-проблем"),
    harden:   bool = typer.Option(False, "--harden",        help="Проверить hardening системы"),
    apply_y:  bool = typer.Option(False, "-y",              help="Применить hardening (только с --harden)"),
    history:  bool = typer.Option(False, "--history",       help="История запусков"),
    compare:  bool = typer.Option(False, "--compare",       help="Сравнение с предыдущим запуском"),
    module:   str  = typer.Option("",   "--module",  "-m", help=(
        "Запустить только один модуль. "
        "Доступные: CPU, Memory, Disk, Hardware, Security, Users, Network, "
        "Docker, Process, Logs, Updates, CVE, Services, Hardening, "
        "S.M.A.R.T, Rootkit, SysInfo"
    )),
    diff:     str  = typer.Option("",   "--diff",          help="Сравнить два JSON-отчёта: old.json:new.json"),
    services: bool = typer.Option(False, "--services",      help="Показать все systemd-сервисы по статусам"),
    sysinfo:  bool = typer.Option(False, "--sysinfo",       help="Показать полную информацию о системе"),
    network:  bool = typer.Option(False, "--network",       help="Показать маршруты, DNS, NTP, интерфейсы"),
    docker:   bool = typer.Option(False, "--docker",        help="Показать контейнеры Docker и их безопасность"),
    users:    bool = typer.Option(False, "--users",         help="Показать пользователей, sudoers, SSH-ключи, входы"),
    logs:     bool = typer.Option(False, "--logs",          help="Показать брутфорс, OOM, ошибки ядра из логов"),
    update_db: bool = typer.Option(False, "--update-db",     help="Обновить локальный кэш CVE (требует интернет)"),
    offline:  bool = typer.Option(False, "--offline",       help="CVE-модуль использует только локальный кэш"),
    send:     str  = typer.Option("",   "--send",          help="Отправить JSON-отчёт на сервер-агент (URL)"),
    agent:    bool = typer.Option(False, "--agent",         help="Отправить отчёт на сервер из config agent.url"),
    rollback: str  = typer.Option("",   "--rollback",      help="Откатить изменения: run_id или 'last'"),
    rollback_list: bool = typer.Option(False, "--rollback-list", help="Показать доступные точки восстановления"),
    show_changelog: bool = typer.Option(False, "--changelog", help="Показать журнал применённых изменений"),
    quiet:    bool = typer.Option(False, "--quiet", "-Q",     help="Не выводить в консоль (для cron/systemd)"),
    run_rkhunter: bool = typer.Option(False, "--run-rkhunter", help="Запустить rkhunter (медленно, ~60с)"),
):
    global console
    if quiet:
        console = Console(quiet=True)

    if diff:
        from output.diff import compare_reports
        parts = diff.split(":")
        if len(parts) == 2:
            compare_reports(parts[0], parts[1])
        else:
            console.print("[red]Формат: --diff old.json:new.json[/]")
        return

    if history:
        _show_history()
        return

    if show_changelog:
        _show_changelog()
        return

    if rollback_list:
        _show_rollback_list()
        return

    if rollback:
        _do_rollback(rollback)
        return

    # --sysinfo / --services / --network / --docker / --users / --logs как самостоятельные команды
    if (sysinfo or services or network or docker or users or logs) and not module:
        if sysinfo:
            ctx = SystemContext()
            ctx.raw_data["sysinfo"] = _collect_raw("SysInfo")
            _print_sysinfo(ctx)
        if services:
            ctx = SystemContext()
            ctx.raw_data["services"] = _collect_raw("Services")
            _print_services(ctx)
        if network:
            ctx = SystemContext()
            ctx.raw_data["network"] = _collect_raw("Network")
            _print_network(ctx)
        if docker:
            ctx = SystemContext()
            ctx.raw_data["docker"] = _collect_raw("Docker")
            _print_docker(ctx)
        if users:
            ctx = SystemContext()
            ctx.raw_data["users"] = _collect_raw("Users")
            _print_users(ctx)
        if logs:
            ctx = SystemContext()
            ctx.raw_data["logs"] = _collect_raw("Logs")
            _print_logs(ctx)
        return

    # Режим CVE-модуля: offline / принудительное обновление кэша
    cfg = load_config()
    CVEModule.set_mode(
        offline=offline or cfg.get("cve", {}).get("offline", False),
        force_refresh=update_db,
    )
    if update_db:
        console.print("[dim]Обновляю локальный кэш CVE...[/]")

    # rkhunter запускается только явно
    if run_rkhunter:
        from modules.rootkit import RootkitModule
        RootkitModule.RUN_RKHUNTER = True

    only = module if module else None

    results, context, total = run_diagnosis(verbose, only=only)
    if total is not None:
        history_save(results, total)

    if only and only.lower() == "sysinfo":
        _print_sysinfo(context)

    _print_diagnosis(results, context, total)

    if only and only.lower() == "services":
        _print_services(context)

    if only and only.lower() == "network":
        _print_network(context)

    if only and only.lower() == "docker":
        _print_docker(context)

    if only and only.lower() == "users":
        _print_users(context)

    if only and only.lower() == "logs":
        _print_logs(context)

    # Если запущен только модуль Hardening — автоматически показать детальный отчёт
    if only and only.lower() == "hardening":
        _print_hardening_report(context)

    if compare:
        _show_compare(results)

    if output:
        _save_output(output, results, context, total)

    if send:
        _send_agent(send, results, context)

    if agent and not send:
        agent_url = cfg.get("agent", {}).get("url")
        if agent_url:
            _send_agent(agent_url, results, context)
        else:
            console.print("\n[yellow]⚠️  agent.url не задан в ~/.linux-doctor/config.yaml[/]")

    if fix:
        _apply_fixes(context)

    if harden:
        if apply_y:
            _apply_hardening(context)
        else:
            _print_hardening_report(context)

    if apply_y and not harden:
        console.print("\n[yellow]⚠️  Флаг -y используется только вместе с --harden[/]")


def _print_sysinfo(context):
    """Полная информация о системе: ядро, ОС, железо, диски, сеть."""
    info = context.raw_data.get("sysinfo", {})
    if not info:
        console.print("[dim]SysInfo модуль не вернул данных.[/]")
        return

    t = Table(box=box.ROUNDED, show_header=False, title="🖥️  Информация о системе", title_style="bold cyan")
    t.add_column("Параметр", style="bold", width=20)
    t.add_column("Значение")

    t.add_row("Hostname",        str(info.get("hostname", "?")))
    t.add_row("ОС",               str(info.get("os", "?")))
    t.add_row("Ядро",             str(info.get("kernel", "?")))
    t.add_row("Ядро (полное)",    str(info.get("kernel_full", "?")))
    t.add_row("Архитектура",      str(info.get("arch", "?")))
    t.add_row("Виртуализация",    str(info.get("virtualization", "?")))
    t.add_row("CPU",              str(info.get("cpu_model", "?")))
    t.add_row("CPU ядра",         str(info.get("cpu_cores", "?")))
    ram = info.get("ram_total")
    t.add_row("RAM всего",        f"{ram} GB" if ram is not None else "?")
    t.add_row("Загрузка системы", str(info.get("boot_time", "?")))
    t.add_row("IP-адреса",        ", ".join(info.get("ip_addresses", [])) or "—")
    t.add_row("Пакетов установлено", str(info.get("package_count", "?")))
    t.add_row("Shell",             str(info.get("shell", "?")))
    t.add_row("Python",            str(info.get("python_version", "?")))

    console.print()
    console.print(t)

    disks = info.get("disks", [])
    if disks:
        dt = Table(box=box.ROUNDED, show_header=True, header_style="bold cyan", title="💾 Диски")
        dt.add_column("Устройство")
        dt.add_column("Размер", justify="right")
        dt.add_column("Использовано", justify="right")
        dt.add_column("Свободно", justify="right")
        dt.add_column("%", justify="right")
        dt.add_column("Точка монтирования")
        for d in disks:
            pcent = d["pcent"].rstrip("%")
            try:
                pc = int(pcent)
                col = "red" if pc >= 90 else ("yellow" if pc >= 75 else "green")
            except Exception:
                col = "white"
            dt.add_row(d["device"], d["size"], d["used"], d["avail"], f"[{col}]{d['pcent']}[/]", d["mount"])
        console.print()
        console.print(dt)


def _print_services(context):
    """Полный список systemd-сервисов по статусам."""
    data = context.raw_data.get("services", {})
    by_state = data.get("by_state", {})
    groups = by_state.get("groups", {})
    counts = by_state.get("counts", {})

    console.print("\n[bold cyan]⚙️  Все сервисы systemd[/]")

    summary = "  ".join(
        f"[{'green' if state=='running' else ('red' if state=='failed' else 'dim')}]{state}={n}[/]"
        for state, n in counts.items()
    )
    console.print(f"   {summary}\n")

    t = Table(box=box.ROUNDED, show_header=True, header_style="bold cyan")
    t.add_column("Статус", width=10)
    t.add_column("Кол-во", justify="center", width=8)
    t.add_column("Сервисы")

    state_labels = {
        "running": ("[green]running[/]", groups.get("running", [])),
        "exited":  ("[dim]exited[/]",     groups.get("exited", [])),
        "dead":    ("[dim]dead[/]",       groups.get("dead", [])),
        "failed":  ("[red]failed[/]",     groups.get("failed", [])),
        "other":   ("[yellow]other[/]",   groups.get("other", [])),
    }

    for label, (style, names) in state_labels.items():
        if not names:
            continue
        shown = ", ".join(names[:8])
        if len(names) > 8:
            shown += f" [dim]...и ещё {len(names)-8}[/]"
        t.add_row(style, str(len(names)), shown)

    console.print(t)


def _print_network(context):
    """Маршруты, DNS, NTP, интерфейсы, открытые порты."""
    data = context.raw_data.get("network", {})
    if not data:
        console.print("[dim]Network модуль не вернул данных.[/]")
        return

    console.print("\n[bold cyan]🌐 Сеть[/]")

    # Интерфейсы
    ifaces = data.get("interfaces", {})
    if ifaces:
        it = Table(box=box.ROUNDED, show_header=True, header_style="bold cyan", title="Интерфейсы")
        it.add_column("Интерфейс")
        it.add_column("Отправлено", justify="right")
        it.add_column("Получено", justify="right")
        it.add_column("Ошибки", justify="right")
        it.add_column("Потери", justify="right")
        for iface, s in ifaces.items():
            err_col = "red" if s["errors"] > 100 else "dim"
            drop_col = "red" if s["drops"] > 100 else "dim"
            it.add_row(
                iface, f"{s['bytes_sent_mb']} MB", f"{s['bytes_recv_mb']} MB",
                f"[{err_col}]{s['errors']}[/]", f"[{drop_col}]{s['drops']}[/]"
            )
        console.print(it)

    # Маршруты
    routes = data.get("routes", {})
    v4 = routes.get("v4", [])
    if v4:
        console.print("\n[bold]Маршруты (IPv4):[/]")
        for r in v4:
            style = "green" if r.startswith("default") else "dim"
            console.print(f"  [{style}]{r}[/]")
    v6 = routes.get("v6", [])
    if v6:
        console.print("\n[bold]Маршруты (IPv6):[/]")
        for r in v6[:10]:
            console.print(f"  [dim]{r}[/]")
        if len(v6) > 10:
            console.print(f"  [dim]...и ещё {len(v6)-10}[/]")

    # DNS
    dns = data.get("dns", {})
    console.print("\n[bold]DNS:[/]")
    resolvers = dns.get("resolvers", [])
    if resolvers:
        console.print(f"  Резолверы: {', '.join(resolvers)}")
    else:
        console.print("  [red]Резолверы не настроены[/]")
    if dns.get("search"):
        console.print(f"  Search domains: {', '.join(dns['search'])}")

    # NTP
    ntp = data.get("ntp", {})
    console.print("\n[bold]Время (NTP):[/]")
    if ntp.get("synced") is True:
        console.print(f"  [green]✅ синхронизировано[/] ({ntp.get('service', '?')})")
    elif ntp.get("synced") is False:
        console.print(f"  [red]✗ не синхронизировано[/] ({ntp.get('service', '?')})")
    else:
        console.print("  [dim]статус неизвестен (нет timedatectl/chronyc)[/]")
    if ntp.get("offset"):
        console.print(f"  Offset: {ntp['offset']}")

    # Открытые порты
    ports = data.get("open_ports", [])
    console.print(f"\n[bold]Открытые порты ({len(ports)}):[/] {', '.join(str(p) for p in ports)}")

    if data.get("connections"):
        console.print(f"\n[red]⚠ Подозрительные соединения:[/] {', '.join(data['connections'])}")


def _print_docker(context):
    """Список контейнеров Docker и их безопасность."""
    data = context.raw_data.get("docker", {})
    if not data:
        console.print("[dim]Docker модуль не вернул данных.[/]")
        return

    if not data.get("available"):
        console.print("\n[dim]🐳 Docker не установлен или не запущен.[/]")
        return

    console.print(f"\n[bold cyan]🐳 Docker[/] [dim](версия {data.get('version', '?')})[/]")

    containers = data.get("containers", [])
    if containers:
        t = Table(box=box.ROUNDED, show_header=True, header_style="bold cyan")
        t.add_column("Имя")
        t.add_column("Образ")
        t.add_column("Статус")
        t.add_column("User")
        t.add_column("Сеть")
        t.add_column("Флаги")
        for c in containers:
            flags = []
            if c["privileged"]:
                flags.append("[red]privileged[/]")
            if c["network_mode"] == "host":
                flags.append("[yellow]host-net[/]")
            if c["image"].endswith(":latest"):
                flags.append("[dim]latest[/]")
            if c["exposed_ports"]:
                flags.append(f"[yellow]exposed:{','.join(c['exposed_ports'])}[/]")
            status_col = "green" if c["running"] else "dim"
            t.add_row(
                c["name"], c["image"], f"[{status_col}]{c['status']}[/]",
                c["user"] or "[dim]root[/]", c["network_mode"] or "-",
                " ".join(flags) if flags else "[dim]—[/]"
            )
        console.print(t)
    else:
        console.print("[dim]Контейнеры не найдены.[/]")

    sock = data.get("sock_perms", {})
    if sock.get("exists"):
        wstyle = "red" if sock["world_writable"] else "green"
        wlabel = "world-writable ⚠" if sock["world_writable"] else "OK"
        console.print(f"\ndocker.sock: группа={sock.get('group','?')}  [{wstyle}]{wlabel}[/]")

    images = data.get("images", [])
    if images:
        console.print(f"\nОбразов: {len(images)}")


def _print_users(context):
    """Полная информация о пользователях, sudoers, SSH-ключах, входах."""
    data = context.raw_data.get("users", {})
    if not data:
        console.print("[dim]Users модуль не вернул данных.[/]")
        return

    console.print("\n[bold cyan]👤 Пользователи и доступ[/]")

    uid0 = data.get("uid0", [])
    if uid0:
        console.print(f"\n[red]UID 0 (root-права) у пользователей:[/] {', '.join(uid0)}")
    else:
        console.print("\n[green]✅ Только root имеет UID 0[/]")

    empty = data.get("empty_passwords", [])
    if empty:
        console.print(f"[red]Пустой пароль у:[/] {', '.join(empty)}")
    else:
        console.print("[green]✅ Пустых паролей не найдено[/]")

    root_locked = data.get("locked_root")
    rl_style = "green" if root_locked else "yellow"
    rl_label = "заблокирован" if root_locked else "НЕ заблокирован"
    console.print(f"Root-аккаунт: [{rl_style}]{rl_label}[/]")

    sudoers = data.get("sudoers", {})
    nopasswd = sudoers.get("nopasswd", [])
    all_cmds = sudoers.get("all_commands", [])

    console.print(f"\n[bold]sudo NOPASSWD ({len(nopasswd)}):[/]")
    if nopasswd:
        for line in nopasswd:
            console.print(f"  [yellow]•[/] {line}")
    else:
        console.print("  [green]не найдено[/]")

    console.print(f"\n[bold]sudo ALL=(ALL) ({len(all_cmds)}):[/]")
    if all_cmds:
        for line in all_cmds[:10]:
            console.print(f"  [dim]•[/] {line}")
        if len(all_cmds) > 10:
            console.print(f"  [dim]...и ещё {len(all_cmds)-10}[/]")
    else:
        console.print("  [dim]не найдено[/]")

    ssh_keys = data.get("ssh_keys", [])
    console.print(f"\n[bold]Слабые SSH-ключи ({len(ssh_keys)}):[/]")
    if ssh_keys:
        for k in ssh_keys:
            console.print(f"  [yellow]•[/] {k}")
    else:
        console.print("  [green]не найдено[/]")

    logins = data.get("last_logins", [])
    if logins:
        console.print(f"\n[bold]Последние входы:[/]")
        for l in logins:
            console.print(f"  [dim]{l}[/]")


def _print_logs(context):
    """Полная информация по логам: брутфорс, OOM, ошибки ядра, sudo."""
    data = context.raw_data.get("logs", {})
    if not data:
        console.print("[dim]Logs модуль не вернул данных.[/]")
        return

    console.print("\n[bold cyan]📜 Логи[/]")

    bf = data.get("bruteforce", [])
    if bf:
        t = Table(box=box.ROUNDED, show_header=True, header_style="bold cyan", title="Брутфорс SSH (топ IP)")
        t.add_column("IP")
        t.add_column("Попыток", justify="right")
        for entry in bf:
            t.add_row(entry["ip"], f"[red]{entry['attempts']}[/]")
        console.print(t)
    else:
        console.print("\n[green]✅ Брутфорс SSH не обнаружен[/]")

    failed = data.get("failed_logins", 0)
    fcol = "red" if failed > 50 else ("yellow" if failed > 0 else "green")
    console.print(f"\nНеудачных входов (failed password / invalid user): [{fcol}]{failed}[/]")

    oom = data.get("oom_kills", [])
    console.print(f"\n[bold]OOM killer ({len(oom)}):[/]")
    if oom:
        for line in oom[:10]:
            console.print(f"  [red]•[/] {line}")
        if len(oom) > 10:
            console.print(f"  [dim]...и ещё {len(oom)-10}[/]")
    else:
        console.print("  [green]не зафиксирован[/]")

    crit = data.get("critical_errors", [])
    console.print(f"\n[bold]Критичные ошибки ядра ({len(crit)}):[/]")
    if crit:
        for line in crit[:10]:
            console.print(f"  [red]•[/] {line}")
        if len(crit) > 10:
            console.print(f"  [dim]...и ещё {len(crit)-10}[/]")
    else:
        console.print("  [green]не найдено[/]")

    sudo_fail = data.get("sudo_attempts", [])
    if sudo_fail:
        console.print(f"\n[bold]Неудачные sudo ({len(sudo_fail)}):[/] {', '.join(sudo_fail[:10])}")

    console.print(
        f"\n[dim]Проверены файлы: {', '.join(LogModule.LOG_FILES)} (последние 2000 строк каждого)[/]"
    )


def _show_changelog():
    entries = changelog_store.load_changelog()
    if not entries:
        console.print("[dim]Журнал изменений пуст.[/]")
        return
    t = Table(title="Журнал изменений", box=box.SIMPLE)
    t.add_column("Время",  style="dim")
    t.add_column("Тип")
    t.add_column("Цель")
    t.add_column("Статус")
    t.add_column("Детали", style="dim")
    for e in entries[-50:][::-1]:
        ok_icon = "[green]✅[/]" if e["ok"] else "[red]❌[/]"
        action_color = {"harden": "cyan", "fix": "yellow", "rollback": "magenta"}.get(e["action"], "white")
        t.add_row(e["ts"][:19], f"[{action_color}]{e['action']}[/]", e["target"], ok_icon, e["details"][:60])
    console.print(t)


def _show_rollback_list():
    from fixes.rollback import list_runs
    runs = list_runs()
    if not runs:
        console.print("[dim]Нет сохранённых изменений для отката.[/]")
        return
    t = Table(title="Доступные точки восстановления", box=box.ROUNDED)
    t.add_column("Run ID", style="bold")
    t.add_column("Время", style="dim")
    t.add_column("Изменения")
    for r in runs[::-1]:
        fixes_str = ", ".join(r["fixes"])
        t.add_row(r["run_id"], r["ts"][:19], fixes_str)
    console.print(t)
    console.print(f"\n[dim]Для отката: [/][bold]linux-doctor --rollback {runs[-1]['run_id']}[/]")
    console.print(f"[dim]Или последний: [/][bold]linux-doctor --rollback last[/]")


def _do_rollback(run_id):
    from fixes.rollback import rollback, rollback_last
    console.print(f"\n[bold cyan]⏪ Откат изменений ({run_id})...[/]")
    if run_id == "last":
        actual_id, results = rollback_last()
        if actual_id is None:
            console.print("[dim]Нет изменений для отката.[/]")
            return
        run_id = actual_id
    else:
        results = rollback(run_id)

    if not results:
        console.print("[dim]Нет файлов для восстановления в этом run_id.[/]")
        return

    for r in results:
        icon = "[green]✅[/]" if r["ok"] else "[red]❌[/]"
        console.print(f"   {icon} {r['file']}: {r['action']}")
    console.print(f"\n[green]Откат run {run_id} завершён.[/]")


def _print_diagnosis(results, context, total):
    diag = Diagnoser().run(context)

    if diag["problems"]:
        console.print("\n[bold yellow]⚠️  Проблемы:[/]")
        for p in diag["problems"]:
            console.print(f"   • {p}")

    if diag["suggestions"]:
        console.print("\n[bold cyan]💡 Рекомендации:[/]")
        for s in diag["suggestions"]:
            console.print(f"   • {s}")


def _show_history():
    hist = history_load()
    if not hist:
        console.print("[dim]История пуста.[/]")
        return
    t = Table(title="История запусков", box=box.SIMPLE)
    t.add_column("Время",  style="dim")
    t.add_column("Score",  justify="center")
    t.add_column("Модули", style="dim")
    for h in hist[-20:][::-1]:
        sc = h["score"]
        sc_style = "green" if sc >= 80 else ("yellow" if sc >= 60 else "red")
        mods = "  ".join(f"{k}={v}" for k, v in h["modules"].items())
        t.add_row(h["ts"][:19], f"[{sc_style}]{sc}[/]", mods)
    console.print(t)


def _show_compare(results):
    hist = history_load()
    if len(hist) < 2:
        return
    prev = hist[-2]["modules"]
    console.print("\n[bold]📊 Сравнение с предыдущим запуском:[/]")
    for name, score in results:
        old  = prev.get(name, score)
        diff = score - old
        arrow = (f"[green]+{diff}[/]" if diff > 0
                 else (f"[red]{diff}[/]" if diff < 0 else "[dim]=[/]"))
        console.print(f"   {name:<14} {old} → {score}  {arrow}")


def _save_output(path, results, context, total):
    hist = history_load()
    diag = Diagnoser().run(context)
    content = (report_html.generate if path.endswith(".html") else report_json.generate)(
        results, diag, context, hist
    )
    with open(path, "w") as f:
        f.write(content)
    console.print(f"\n[green]✅ Отчёт сохранён: {path}[/]")


def _send_agent(url, results, context):
    from output.agent import send_report
    cfg   = load_config()
    token = cfg.get("agent", {}).get("token")
    hist  = history_load()
    diag  = Diagnoser().run(context)
    report_str = report_json.generate(results, diag, context, hist)
    ok, msg = send_report(url, report_str, token=token)
    icon = "[green]✅[/]" if ok else "[red]❌[/]"
    console.print(f"\n{icon} Агент → {url}: {msg}")


def _apply_fixes(context):
    from fixes.auto_fix import apply
    console.print("\n[bold]🔧 Применяю security-исправления...[/]")
    fixes, run_id = apply(context.raw_data.get("security", {}))
    if not fixes:
        console.print("   [dim]Нет автоматических исправлений.[/]")
        return
    for f in fixes:
        icon = "[green]✅[/]" if f["ok"] else "[red]❌[/]"
        console.print(f"   {icon} {f['fix']}: {f['msg']}")
    console.print(f"\n   [dim]Run ID: {run_id} — откат: linux-doctor --rollback {run_id}[/]")


def _print_hardening_report(context):
    raw = context.raw_data.get("hardening", {})
    if not raw:
        return
    console.print("\n[bold cyan]🛡️  Hardening — детальный отчёт[/]")

    sysctl = raw.get("sysctl", {})
    bad  = {k: v for k, v in sysctl.items() if not v["ok"]}
    good = {k: v for k, v in sysctl.items() if v["ok"]}
    console.print(f"\n  [bold]sysctl[/] — [green]{len(good)} OK[/] / [yellow]{len(bad)} не настроено[/]")
    for k, v in bad.items():
        console.print(f"    [red]✗[/] {k} = {v['value']!r}  [dim](нужно: {v['expected']})[/]")

    ssh = raw.get("ssh", {})
    ssh_bad  = {p: v for p, v in ssh.items() if not v["ok"]}
    ssh_good = {p: v for p, v in ssh.items() if v["ok"]}
    console.print(f"\n  [bold]SSH[/] — [green]{len(ssh_good)} OK[/] / [yellow]{len(ssh_bad)} не настроено[/]")
    for p, v in ssh_bad.items():
        console.print(f"    [red]✗[/] {v['desc']}  [dim](текущее: {v['value']!r})[/]")

    pam = raw.get("pam", {})
    console.print(f"\n  [bold]PAM[/]")
    _icon_line("Сложность паролей",         pam.get("password_complexity"))
    _icon_line("Блокировка после N попыток", pam.get("account_lockout"))

    console.print(f"\n  [bold]Прочее[/]")
    mac = raw.get("apparmor", {})
    _icon_line("AppArmor / SELinux активен", mac.get("apparmor") or mac.get("selinux"))
    _icon_line("auditd запущен",             raw.get("auditd"))
    _icon_line("umask 027/077 настроен",     raw.get("umask"))
    _icon_line("Core dumps отключены",       raw.get("core_dumps"))

    suid = raw.get("suid_files", [])
    if suid:
        console.print(f"\n  [bold]SUID/SGID[/] — [red]{len(suid)} подозрительных:[/]")
        for f in suid[:10]:
            console.print(f"    [red]✗[/] {f}")
    else:
        console.print(f"\n  [bold]SUID/SGID[/] — [green]✅ чисто[/]")

    console.print(
        "\n  [dim]Для применения: [/][bold]linux-doctor --harden -y[/]"
    )


def _icon_line(label, ok):
    icon = "[green]✅[/]" if ok else "[red]✗[/]"
    console.print(f"    {icon} {label}")


def _apply_hardening(context):
    from fixes.hardening_fix import apply
    console.print("\n[bold cyan]🛡️  Применяю hardening...[/]")
    console.print("   [dim]Бэкапы → ~/.linux-doctor/backups/[/]\n")
    fixes, run_id = apply(context.raw_data.get("hardening", {}))
    if not fixes:
        console.print("   [green]Система уже hardened.[/]")
        return
    for f in fixes:
        icon = "[green]✅[/]" if f["ok"] else "[red]❌[/]"
        console.print(f"   {icon} [bold]{f['fix']}[/]: {f['msg']}")
    console.print("\n   [dim]umask и PAM вступят в силу после перелогина.[/]")
    console.print(f"   [dim]Run ID: {run_id} — откат: linux-doctor --rollback {run_id}[/]")


if __name__ == "__main__":
    app()
