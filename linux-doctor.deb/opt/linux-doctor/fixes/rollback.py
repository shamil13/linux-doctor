import os
import shutil
from storage import changelog


def list_runs():
    """Список уникальных run_id с количеством изменённых файлов, последние сверху."""
    manifest = changelog.load_manifest()
    runs = {}
    for entry in manifest:
        runs.setdefault(entry["run_id"], {"ts": entry["ts"], "files": [], "fixes": set()})
        runs[entry["run_id"]]["files"].append(entry["original"])
        runs[entry["run_id"]]["fixes"].add(entry["fix"])
    return [
        {"run_id": rid, "ts": v["ts"], "files": v["files"], "fixes": sorted(v["fixes"])}
        for rid, v in sorted(runs.items())
    ]


def rollback(run_id):
    """Откатить изменения, сделанные в рамках run_id. Возвращает список результатов."""
    entries = changelog.entries_for_run(run_id)
    results = []

    for entry in entries:
        original = entry["original"]
        backup   = entry["backup"]
        try:
            if backup and os.path.exists(backup):
                shutil.copy2(backup, original)
                results.append({"file": original, "ok": True, "action": "восстановлен из бэкапа"})
            elif backup is None:
                # Файла не существовало до изменения — удаляем созданный
                if os.path.exists(original):
                    os.remove(original)
                    results.append({"file": original, "ok": True, "action": "удалён (был создан этим запуском)"})
                else:
                    results.append({"file": original, "ok": True, "action": "уже отсутствует"})
            else:
                results.append({"file": original, "ok": False, "action": "файл бэкапа не найден"})
        except Exception as e:
            results.append({"file": original, "ok": False, "action": str(e)})

    # Перезагружаем сервисы которые могли быть затронуты
    affected_fixes = {e["fix"] for e in entries}
    if any("SSH" in f for f in affected_fixes):
        try:
            import subprocess
            subprocess.run(["systemctl", "reload", "ssh"], capture_output=True, timeout=10)
        except Exception:
            pass

    for r in results:
        changelog.log_action("rollback", r["file"], r["ok"], r["action"])

    return results


def rollback_last():
    run_id = changelog.last_run_id()
    if not run_id:
        return None, []
    return run_id, rollback(run_id)
