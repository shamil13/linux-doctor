import subprocess
import re
import os
import shutil
from datetime import datetime
from storage import changelog

BACKUP_DIR = os.path.expanduser("~/.linux-doctor/backups")


def _backup(path, fix_name, run_id):
    os.makedirs(BACKUP_DIR, exist_ok=True)
    if os.path.exists(path):
        ts = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        name = path.replace("/", "_")
        dst = os.path.join(BACKUP_DIR, f"{name}.{ts}.bak")
        shutil.copy2(path, dst)
        changelog.record_backup(path, dst, fix_name, run_id)
        return dst
    return None


def _fix_ssh_password(run_id):
    cfg = "/etc/ssh/sshd_config"
    _backup(cfg, "Отключить парольный SSH", run_id)
    try:
        with open(cfg) as f:
            content = f.read()
        content = re.sub(r"(?m)^#?PasswordAuthentication\s+\w+", "PasswordAuthentication no", content)
        if "PasswordAuthentication no" not in content:
            content += "\nPasswordAuthentication no\n"
        with open(cfg, "w") as f:
            f.write(content)
        subprocess.run(["systemctl", "reload", "ssh"], capture_output=True)
        return True, "PasswordAuthentication no установлен, sshd перезагружен"
    except Exception as e:
        return False, str(e)


def _fix_firewall(run_id):
    try:
        subprocess.run(["ufw", "--force", "enable"], capture_output=True, check=True)
        return True, "UFW включён"
    except Exception as e:
        return False, str(e)


def apply(raw_security):
    results = []
    run_id = changelog.new_run_id()
    checks = [
        (raw_security.get("ssh_password"),      _fix_ssh_password, "Отключить парольный SSH"),
        (not raw_security.get("firewall"),       _fix_firewall,     "Включить UFW фаервол"),
    ]
    for condition, fix_fn, desc in checks:
        if condition:
            ok, msg = fix_fn(run_id)
            results.append({"fix": desc, "ok": ok, "msg": msg})
            changelog.log_action("fix", desc, ok, msg)
    return results, run_id
