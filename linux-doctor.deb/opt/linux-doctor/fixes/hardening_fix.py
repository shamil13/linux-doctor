import subprocess
import os
import re
import shutil
from datetime import datetime
from storage import changelog

BACKUP_DIR = os.path.expanduser("~/.linux-doctor/backups")


def _backup(path, fix_name, run_id):
    """Создать резервную копию файла перед изменением и записать в manifest."""
    os.makedirs(BACKUP_DIR, exist_ok=True)
    if os.path.exists(path):
        ts = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        name = path.replace("/", "_")
        dst = os.path.join(BACKUP_DIR, f"{name}.{ts}.bak")
        shutil.copy2(path, dst)
        changelog.record_backup(path, dst, fix_name, run_id)
        return dst
    else:
        # Файла не было — при rollback его нужно будет удалить
        changelog.record_backup(path, None, fix_name, run_id)
        return None


def fix_sysctl(failed_keys, run_id):
    """Записать безопасные значения sysctl в /etc/sysctl.d/99-hardening.conf."""
    SAFE_VALUES = {
        "net.ipv4.ip_forward":                  "0",
        "net.ipv4.conf.all.send_redirects":      "0",
        "net.ipv4.conf.default.send_redirects":  "0",
        "net.ipv4.conf.all.accept_redirects":    "0",
        "net.ipv4.conf.default.accept_redirects":"0",
        "net.ipv4.conf.all.accept_source_route": "0",
        "net.ipv4.tcp_syncookies":               "1",
        "net.ipv4.conf.all.log_martians":        "1",
        "net.ipv4.icmp_echo_ignore_broadcasts":  "1",
        "kernel.randomize_va_space":             "2",
        "kernel.dmesg_restrict":                 "1",
        "kernel.core_uses_pid":                  "1",
        "fs.suid_dumpable":                      "0",
    }
    path = "/etc/sysctl.d/99-hardening.conf"
    _backup(path, "sysctl hardening", run_id)
    try:
        lines = ["# Linux Doctor — автоматический hardening\n"]
        for key in failed_keys:
            if key in SAFE_VALUES:
                lines.append(f"{key} = {SAFE_VALUES[key]}\n")
        with open(path, "w") as f:
            f.writelines(lines)
        subprocess.run(["sysctl", "-p", path], capture_output=True, timeout=10)
        return True, f"Записано {len(lines)-1} параметров в {path}"
    except Exception as e:
        return False, str(e)


def fix_ssh_hardening(failed_params, run_id):
    """Применить hardening SSH конфига."""
    SAFE_VALUES = {
        "Protocol":               "2",
        "PermitRootLogin":        "no",
        "PasswordAuthentication": "no",
        "PermitEmptyPasswords":   "no",
        "X11Forwarding":          "no",
        "MaxAuthTries":           "4",
        "LoginGraceTime":         "60",
        "AllowAgentForwarding":   "no",
        "ClientAliveInterval":    "300",
        "ClientAliveCountMax":    "2",
    }
    cfg = "/etc/ssh/sshd_config"
    _backup(cfg, "SSH hardening", run_id)
    try:
        with open(cfg) as f:
            content = f.read()
        for param in failed_params:
            val = SAFE_VALUES.get(param)
            if not val:
                continue
            pattern = rf"(?m)^#?{param}\s+.*"
            replacement = f"{param} {val}"
            if re.search(pattern, content):
                content = re.sub(pattern, replacement, content)
            else:
                content += f"\n{replacement}\n"
        with open(cfg, "w") as f:
            f.write(content)
        subprocess.run(["systemctl", "reload", "ssh"], capture_output=True, timeout=10)
        return True, f"Обновлено {len(failed_params)} SSH-параметров, sshd перезагружен"
    except Exception as e:
        return False, str(e)


def fix_pam_lockout(run_id):
    """Настроить блокировку аккаунта после 5 неудачных попыток через pam_faillock."""
    path = "/etc/pam.d/common-auth"
    _backup(path, "PAM lockout", run_id)
    try:
        with open(path) as f:
            content = f.read()
        if "pam_faillock" in content:
            return True, "pam_faillock уже настроен"
        insert = (
            "auth    required   pam_faillock.so preauth silent audit deny=5 unlock_time=900\n"
        )
        content = insert + content
        with open(path, "w") as f:
            f.write(content)
        return True, "pam_faillock настроен (блокировка после 5 попыток на 15 минут)"
    except Exception as e:
        return False, str(e)


def fix_umask(run_id):
    """Установить umask 027 в /etc/profile."""
    path = "/etc/profile"
    _backup(path, "umask 027", run_id)
    try:
        with open(path) as f:
            content = f.read()
        if "umask 027" in content or "umask 077" in content:
            return True, "umask уже настроен"
        content = re.sub(r"umask\s+\d+", "umask 027", content)
        if "umask 027" not in content:
            content += "\numask 027\n"
        with open(path, "w") as f:
            f.write(content)
        return True, "umask 027 установлен в /etc/profile"
    except Exception as e:
        return False, str(e)


def fix_core_dumps(run_id):
    """Отключить core dumps через limits.conf."""
    path = "/etc/security/limits.d/99-nodumps.conf"
    _backup(path, "Отключение core dumps", run_id)
    try:
        with open(path, "w") as f:
            f.write("# Linux Doctor — отключение core dumps\n")
            f.write("*    hard    core    0\n")
            f.write("*    soft    core    0\n")
        subprocess.run(
            ["sysctl", "-w", "fs.suid_dumpable=0"],
            capture_output=True, timeout=5
        )
        return True, f"Core dumps отключены в {path}"
    except Exception as e:
        return False, str(e)


def fix_auditd(run_id):
    """Установить и запустить auditd."""
    try:
        subprocess.run(
            ["apt-get", "install", "-y", "auditd"],
            capture_output=True, timeout=60
        )
        subprocess.run(["systemctl", "enable", "--now", "auditd"], capture_output=True, timeout=10)
        return True, "auditd установлен и запущен"
    except Exception as e:
        return False, str(e)


def apply(raw_data):
    """Применить все доступные hardening-исправления. Возвращает (results, run_id)."""
    results = []
    run_id = changelog.new_run_id()

    failed_sysctl = [k for k, v in raw_data.get("sysctl", {}).items() if not v["ok"]]
    if failed_sysctl:
        ok, msg = fix_sysctl(failed_sysctl, run_id)
        results.append({"fix": "sysctl hardening", "ok": ok, "msg": msg})
        changelog.log_action("harden", "sysctl hardening", ok, msg)

    failed_ssh = [param for param, v in raw_data.get("ssh", {}).items() if not v["ok"]]
    if failed_ssh:
        ok, msg = fix_ssh_hardening(failed_ssh, run_id)
        results.append({"fix": "SSH hardening", "ok": ok, "msg": msg})
        changelog.log_action("harden", "SSH hardening", ok, msg)

    if not raw_data.get("pam", {}).get("account_lockout"):
        ok, msg = fix_pam_lockout(run_id)
        results.append({"fix": "PAM блокировка аккаунтов", "ok": ok, "msg": msg})
        changelog.log_action("harden", "PAM блокировка аккаунтов", ok, msg)

    if not raw_data.get("umask"):
        ok, msg = fix_umask(run_id)
        results.append({"fix": "umask 027", "ok": ok, "msg": msg})
        changelog.log_action("harden", "umask 027", ok, msg)

    if not raw_data.get("core_dumps"):
        ok, msg = fix_core_dumps(run_id)
        results.append({"fix": "Отключение core dumps", "ok": ok, "msg": msg})
        changelog.log_action("harden", "Отключение core dumps", ok, msg)

    if not raw_data.get("auditd"):
        ok, msg = fix_auditd(run_id)
        results.append({"fix": "auditd", "ok": ok, "msg": msg})
        changelog.log_action("harden", "auditd", ok, msg)

    return results, run_id
