import json
import os
import time
import hashlib

CACHE_DIR  = os.path.expanduser("~/.linux-doctor/cache")
CACHE_FILE = os.path.join(CACHE_DIR, "cve_cache.json")
CACHE_TTL  = 3600  # 1 час


def make_key(kernel, packages):
    """Хэш от ядра + версий проверяемых пакетов — для определения актуальности кэша."""
    data = (kernel or "") + "|" + "|".join(
        f"{p['name']}={p['version']}" for p in packages
    )
    return hashlib.sha256(data.encode()).hexdigest()


def load():
    try:
        with open(CACHE_FILE) as f:
            return json.load(f)
    except Exception:
        return None


def save(key, cves):
    os.makedirs(CACHE_DIR, exist_ok=True)
    with open(CACHE_FILE, "w") as f:
        json.dump({
            "key": key,
            "timestamp": time.time(),
            "cves": cves,
        }, f, indent=2)


def get_valid(key, ttl=CACHE_TTL, ignore_ttl=False):
    """Вернуть кэшированные CVE если ключ совпадает и кэш не устарел."""
    cache = load()
    if not cache or cache.get("key") != key:
        return None
    age = time.time() - cache.get("timestamp", 0)
    if not ignore_ttl and age > ttl:
        return None
    return cache.get("cves", [])


def age_seconds():
    cache = load()
    if not cache:
        return None
    return time.time() - cache.get("timestamp", 0)
