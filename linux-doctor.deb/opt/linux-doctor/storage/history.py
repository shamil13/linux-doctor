import json
import os
from datetime import datetime

HISTORY_DIR = os.path.expanduser("~/.linux-doctor")
HISTORY_FILE = os.path.join(HISTORY_DIR, "history.json")

def save(results, total_score):
    os.makedirs(HISTORY_DIR, exist_ok=True)
    history = load_all()
    history.append({
        "ts": datetime.now().isoformat(),
        "score": total_score,
        "modules": {name: score for name, score in results},
    })
    history = history[-100:]  # храним последние 100 запусков
    with open(HISTORY_FILE, "w") as f:
        json.dump(history, f, indent=2)

def load_all():
    if not os.path.exists(HISTORY_FILE):
        return []
    try:
        with open(HISTORY_FILE) as f:
            return json.load(f)
    except Exception:
        return []

def trend(module_name):
    """Возвращает тренд: +N, -N или = относительно предыдущего запуска."""
    history = load_all()
    if len(history) < 2:
        return None
    prev = history[-2]["modules"].get(module_name)
    curr = history[-1]["modules"].get(module_name)
    if prev is None or curr is None:
        return None
    diff = curr - prev
    if diff > 0:
        return f"+{diff}"
    elif diff < 0:
        return str(diff)
    return "="
