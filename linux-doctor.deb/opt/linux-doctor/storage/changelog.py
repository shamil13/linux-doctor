import json
import os
import time
from datetime import datetime

BASE_DIR      = os.path.expanduser("~/.linux-doctor")
CHANGELOG_FILE = os.path.join(BASE_DIR, "changelog.json")
MANIFEST_FILE  = os.path.join(BASE_DIR, "backups", "manifest.json")


# ── Changelog: журнал применённых fix/harden действий ────────────────────────

def log_action(action, target, ok, details=""):
    os.makedirs(BASE_DIR, exist_ok=True)
    entries = load_changelog()
    entries.append({
        "ts":      datetime.now().isoformat(),
        "action":  action,
        "target":  target,
        "ok":      ok,
        "details": details,
    })
    entries = entries[-300:]
    with open(CHANGELOG_FILE, "w") as f:
        json.dump(entries, f, indent=2, ensure_ascii=False)


def load_changelog():
    try:
        with open(CHANGELOG_FILE) as f:
            return json.load(f)
    except Exception:
        return []


# ── Backup manifest: для --rollback ──────────────────────────────────────────

def record_backup(original_path, backup_path, fix_name, run_id):
    os.makedirs(os.path.dirname(MANIFEST_FILE), exist_ok=True)
    manifest = load_manifest()
    manifest.append({
        "run_id":   run_id,
        "ts":       datetime.now().isoformat(),
        "original": original_path,
        "backup":   backup_path,
        "fix":      fix_name,
    })
    with open(MANIFEST_FILE, "w") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)


def load_manifest():
    try:
        with open(MANIFEST_FILE) as f:
            return json.load(f)
    except Exception:
        return []


def last_run_id():
    manifest = load_manifest()
    if not manifest:
        return None
    return manifest[-1]["run_id"]


def entries_for_run(run_id):
    return [m for m in load_manifest() if m["run_id"] == run_id]


def new_run_id():
    return datetime.now().strftime("%Y%m%d_%H%M%S")
