from modules.cpu import CPUModule
from modules.memory import MemoryModule
from modules.disk import DiskModule
from modules.security import SecurityModule
from modules.network import NetworkModule
from modules.process import ProcessModule
from modules.logs import LogModule
from modules.updates import UpdateModule
from modules.services import ServiceModule
from modules.hardening import HardeningModule
from modules.smart import SmartModule
from modules.cve import CVEModule
from modules.rootkit import RootkitModule
from modules.hardware import HardwareModule
from modules.users import UsersModule
from modules.sysinfo import SysInfoModule
from modules.docker import DockerModule


def get_modules(disabled=None):
    disabled = [d.lower() for d in (disabled or [])]
    all_modules = [
        SysInfoModule(),
        CPUModule(),
        MemoryModule(),
        DiskModule(),
        HardwareModule(),
        SecurityModule(),
        UsersModule(),
        NetworkModule(),
        DockerModule(),
        ProcessModule(),
        LogModule(),
        UpdateModule(),
        CVEModule(),
        ServiceModule(),
        HardeningModule(),
        SmartModule(),
        RootkitModule(),
    ]
    return [m for m in all_modules if m.name.lower() not in disabled]
