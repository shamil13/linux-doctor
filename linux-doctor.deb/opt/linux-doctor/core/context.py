from dataclasses import dataclass, field

@dataclass
class SystemContext:
    raw_data: dict = field(default_factory=dict)
    analysis: dict = field(default_factory=dict)
    issues: list = field(default_factory=list)
    score: int = 100