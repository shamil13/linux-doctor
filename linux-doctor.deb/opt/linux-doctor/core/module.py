from abc import ABC, abstractmethod

class Module(ABC):
    name = "base"
    weight = 10

    @abstractmethod
    def collect(self): pass

    @abstractmethod
    def analyze(self, data): pass

    @abstractmethod
    def report(self, analysis): pass